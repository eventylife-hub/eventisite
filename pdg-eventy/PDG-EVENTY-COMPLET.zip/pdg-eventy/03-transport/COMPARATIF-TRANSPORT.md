# Comparatif Transport — Eventy

## Types de transport à proposer

### 1. Autocar / Bus (principal pour voyages de groupe)

#### Grille tarifaire 2025-2026

| Véhicule | Places | Prix/jour HT | Prix/km HT | Idéal pour |
|----------|--------|-------------|-----------|------------|
| Minibus | 8-20 | 400€ - 550€ | 2,50€ - 3,50€ | Petits groupes |
| Midibus | 20-30 | 500€ - 700€ | 3,00€ - 4,00€ | Groupes moyens |
| Bus moyen | 30-40 | 700€ - 900€ | 3,50€ - 4,50€ | Groupes standards |
| Autocar | 40-55 | 900€ - 1 200€ | 4,00€ - 5,00€ | Grands groupes |

**Prix moyen constaté** : ~988€/jour pour un autocar standard (36-55 places)

#### Saisonnalité
- Haute saison (mars-octobre) : +15% à +25%
- Pic mai-juin : +26% (ponts + sorties scolaires)
- Basse saison (novembre-février) : tarifs plancher

#### Plateformes de réservation
- **Groupito** (groupito.com) — Comparateur en ligne, devis instantanés
- **Centrale Autocar** (centrale-autocar.com) — Réseau national
- **Cars de France** (cars-de-france.com) — Réseau certifié
- **Autocar Location** (autocar-location.com) — Devis RSE

### 2. Train (SNCF)

| Offre | Avantage | Inconvénient |
|-------|----------|-------------|
| Tarifs groupes SNCF (10+ pers.) | -20% à -50% | Réservation J-120 max |
| TGV Intercités | Rapide, confortable | Horaires fixes |
| TER régional | Économique | Limité en portée |

**Action** : Créer un compte pro SNCF Groupes (sncf-connect.com/groupe)

### 3. Vol (pour destinations lointaines)

| Type | Commission | Notes |
|------|-----------|-------|
| Vols réguliers (BSP) | 1-3% | Nécessite accréditation IATA |
| Vols charter | Négociable | Pour gros volumes |
| Packages TO | 5-10% | Via tour-opérateurs partenaires |

**Note** : L'accréditation IATA est complexe et coûteuse. En phase de lancement, passer par un consolidateur ou un TO.

---

## Stratégie d'approvisionnement

### Phase 1 (lancement — 6 premiers mois)
- Autocar via plateformes comparatrices (Groupito, Centrale Autocar)
- Train via SNCF Groupes
- Pas de vol en propre — passer par des TO

### Phase 2 (stabilisation — mois 6-18)
- Négocier des contrats cadre avec 2-3 autocaristes régionaux
- Volume discount : -10% à -15% pour engagement annuel
- Partenariat SNCF Pro

### Phase 3 (scale — 18+ mois)
- Flotte de prestataires dédiés avec tarifs négociés
- Éventuellement accréditation IATA pour les vols
- Vols charter pour les gros groupes

---

## Checklist transport

- [ ] Créer comptes sur Groupito et Centrale Autocar
- [ ] Ouvrir un compte SNCF Groupes Pro
- [ ] Demander 5 devis d'autocaristes locaux (Île-de-France)
- [ ] Demander 3 devis d'autocaristes régionaux (PACA, Auvergne, Bretagne)
- [ ] Négocier les premiers contrats cadre
- [ ] Identifier 2-3 TO partenaires pour les vols
- [ ] Intégrer les APIs transport dans le backend (si disponibles)

---

## Template email de demande de devis autocar

```
Objet : Demande de partenariat transport — Eventy (agence de voyages de groupe)

Bonjour,

Je suis David, fondateur d'Eventy, une agence de voyages spécialisée dans l'organisation de voyages de groupe.

Nous recherchons un partenaire transport fiable pour nos prestations régulières :
- Groupes de 15 à 50 personnes
- Trajets Île-de-France + France entière
- Fréquence estimée : 2-5 déplacements/mois (croissant)

Pourriez-vous nous communiquer :
1. Votre grille tarifaire (journée + km)
2. Vos conditions pour un contrat cadre annuel
3. Votre flotte disponible (types de véhicules)
4. Vos certifications et assurances

Nous sommes immatriculés auprès d'Atout France (numéro en cours).

Cordialement,
David
Eventy — Voyages de groupe
eventylife@gmail.com
```

# Checklist Complète de Lancement — Eventy

> Cocher chaque item au fur et à mesure. Ordre recommandé de haut en bas.

---

## PHASE 1 — Création juridique (Semaine 1-2)

### Société
- [ ] Choisir un avocat ou legaltech pour les statuts
- [ ] Rédiger les statuts SAS
- [ ] Définir le capital social (minimum 1 000€ recommandé)
- [ ] Ouvrir un compte de dépôt de capital
- [ ] Déposer le capital social
- [ ] Publier l'annonce légale (JAL)
- [ ] Déposer le dossier au greffe (ou via Inpi.fr)
- [ ] Recevoir le Kbis
- [ ] Obtenir le numéro SIRET
- [ ] Inscrire l'activité : Code APE 7911Z (agences de voyages)

### Compte bancaire
- [ ] Ouvrir le compte professionnel (Qonto / Shine / banque traditionnelle)
- [ ] Commander la carte bancaire pro
- [ ] Configurer les virements SEPA
- [ ] Mettre en place le rapprochement bancaire

---

## PHASE 2 — Obligations agence de voyages (Semaine 2-4)

### Garantie financière
- [ ] Contacter l'APST (ou assureur privé)
- [ ] Préparer le dossier de candidature
- [ ] Fournir : Kbis, statuts, business plan, prévisionnel
- [ ] Constituer la contre-garantie si demandée
- [ ] Soumettre le dossier
- [ ] Obtenir l'attestation de garantie

### RC Pro
- [ ] Demander devis sur Orus, Coover, Hiscox, Assurup
- [ ] Comparer (prix, franchise, plafonds, exclusions)
- [ ] Souscrire le contrat
- [ ] Obtenir l'attestation RC Pro

### Immatriculation Atout France
- [ ] Préparer le dossier complet (cf. IMMATRICULATION.md)
- [ ] Joindre : Kbis, attestation garantie, attestation RC Pro, capacité professionnelle
- [ ] Déposer le dossier sur registre-operateurs-de-voyages.atout-france.fr
- [ ] Attendre la validation (~1 mois)
- [ ] Recevoir le numéro IM0XXXXX
- [ ] Afficher le numéro sur le site et tous les documents

---

## PHASE 3 — Juridique & conformité (Semaine 3-6, en parallèle)

### CGV / CGU
- [ ] Engager un avocat droit du tourisme
- [ ] Faire rédiger les CGV conformes au Code du Tourisme
- [ ] Faire rédiger les CGU de la plateforme
- [ ] Faire rédiger les mentions légales
- [ ] Faire rédiger la politique de confidentialité
- [ ] Faire rédiger le contrat-type partenaire
- [ ] Publier tous les documents sur le site

### RGPD
- [ ] Nommer le responsable de traitement (David, PDG)
- [ ] Rédiger le registre des traitements
- [ ] Vérifier le module DSAR du backend
- [ ] Configurer les cookies (consentement opt-in)
- [ ] Signer les DPA avec sous-traitants (Stripe, cloud, email)

---

## PHASE 4 — Tech & déploiement (Semaine 3-6, en parallèle)

### Infrastructure
- [ ] Créer le compte Scaleway (ou OVH)
- [ ] Déployer le backend NestJS
- [ ] Configurer la base PostgreSQL managée
- [ ] Configurer le domaine eventy.fr (DNS)
- [ ] Activer HTTPS (Let's Encrypt / Cloudflare)
- [ ] Configurer les headers sécurité (CORS, CSP, HSTS)
- [ ] Activer le rate limiting
- [ ] Configurer Cloudflare (CDN + WAF)

### CI/CD
- [ ] Créer le repo GitHub (ou continuer l'existant)
- [ ] Configurer GitHub Actions (build + test + deploy)
- [ ] Configurer les environnements (staging + production)
- [ ] Mettre en place les backups automatiques DB

### Corrections
- [ ] Corriger les 5 tests setAvatar
- [ ] Exécuter npm audit et corriger les vulnérabilités
- [ ] Vérifier tous les endpoints admin protégés
- [ ] Activer les logs d'audit
- [ ] Tester les webhooks Stripe en production

### Email
- [ ] Configurer Google Workspace (email pro)
- [ ] Configurer le service d'emails transactionnels (Brevo / Resend)
- [ ] Tester l'envoi : confirmation, devis, facture, notification
- [ ] Configurer SPF + DKIM + DMARC

### Monitoring
- [ ] Configurer UptimeRobot (uptime)
- [ ] Configurer Sentry (erreurs)
- [ ] Configurer les alertes email/Slack

---

## PHASE 5 — Partenaires (Semaine 4-8, en parallèle)

### Prospection
- [ ] Identifier 10 hôtels/gîtes cibles
- [ ] Identifier 10 prestataires activités cibles
- [ ] Identifier 5 autocaristes régionaux
- [ ] Identifier 3 restaurants partenaires potentiels
- [ ] Envoyer les emails de premier contact
- [ ] Relancer à J+7 si pas de réponse
- [ ] Programmer les appels / visites

### Négociation
- [ ] Obtenir les grilles tarifaires
- [ ] Négocier les commissions
- [ ] Signer les contrats / accords partenaires
- [ ] Intégrer les prestataires dans le module HRA

---

## PHASE 6 — Marketing (Semaine 4-8, en parallèle)

### Présence en ligne
- [ ] Créer la page Instagram @eventy.fr
- [ ] Créer la page LinkedIn Eventy
- [ ] Créer la page Facebook Eventy
- [ ] Revendiquer la fiche Google Business Profile
- [ ] Créer le profil TripAdvisor

### Contenu
- [ ] Rédiger 10 articles SEO fondation
- [ ] Préparer 20 posts réseaux sociaux (1 mois d'avance)
- [ ] Créer les visuels de lancement (Canva)
- [ ] Rédiger le communiqué de presse lancement

### Publicité
- [ ] Créer le compte Google Ads
- [ ] Préparer les campagnes de lancement
- [ ] Définir les mots-clés cibles
- [ ] Créer les landing pages de conversion
- [ ] Configurer le pixel de suivi / analytics

---

## PHASE 7 — Pré-lancement (Semaine 7-8)

- [ ] Tester le parcours client complet (devis → paiement → confirmation)
- [ ] Tester le parcours pro (inscription → listing → réservation)
- [ ] Vérifier l'affichage mobile responsive
- [ ] Vérifier la conformité : numéro Atout France, CGV, mentions légales
- [ ] Faire tester par 3-5 personnes extérieures
- [ ] Corriger les bugs remontés
- [ ] Préparer le premier voyage test (offre de lancement)

---

## PHASE 8 — LANCEMENT (Semaine 8-12)

- [ ] Publier le site en production
- [ ] Activer les paiements Stripe en mode live
- [ ] Publier le communiqué de presse
- [ ] Lancer les campagnes Google Ads
- [ ] Publier sur les réseaux sociaux
- [ ] Envoyer les emails de lancement (réseau personnel + pros)
- [ ] Proposer l'offre de lancement aux premiers clients
- [ ] Surveiller le monitoring 24h/24 les premiers jours

---

## POST-LANCEMENT (M+1 à M+3)

- [ ] Analyser les KPIs : trafic, conversion, CA
- [ ] Recueillir les premiers avis clients
- [ ] Ajuster les prix si nécessaire
- [ ] Développer le réseau de partenaires
- [ ] Planifier les voyages du mois suivant
- [ ] Faire le point avec l'expert-comptable
- [ ] Commencer le développement du dashboard admin

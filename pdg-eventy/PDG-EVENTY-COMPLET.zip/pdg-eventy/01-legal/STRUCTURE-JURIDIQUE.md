# Choix de la structure juridique — Eventy

## Recommandation : SAS (Société par Actions Simplifiée)

La SAS est la forme juridique la plus adaptée pour Eventy (plateforme tech + agence de voyages) pour les raisons suivantes :

- Flexibilité statutaire totale (gouvernance, droits de vote, entrée/sortie capital)
- Compatible BSPCE, actions gratuites, stock-options (clé pour attirer des talents tech)
- Crédibilité auprès des investisseurs (actions de préférence possibles)
- Pas de capital minimum (1€ symbolique possible, mais 1 000€ - 5 000€ recommandé)

## Comparatif SAS vs SARL

| Critère | SAS | SARL |
|---------|-----|------|
| Capital minimum | 1€ | 1€ |
| Dirigeant | Président (assimilé salarié) | Gérant (TNS si majoritaire) |
| Charges sociales dirigeant | ~75% sur rémunération | ~45% (TNS) |
| Flexibilité statuts | Totale | Encadrée par la loi |
| Cession de parts | Libre (sauf clause) | Agrément obligatoire |
| BSPCE / Stock-options | Oui | Non |
| Investisseurs | Très adapté | Peu adapté |
| Coût création | 500€ - 3 000€ | 500€ - 2 000€ |
| Adapté startup tech | Oui | Non |

## Coûts de création SAS

| Poste | Fourchette | Notes |
|-------|-----------|-------|
| Rédaction statuts (avocat) | 1 500€ - 3 000€ | Ou legaltech 100-300€ |
| Publication annonce légale | 150€ - 250€ | Journal d'annonces légales |
| Immatriculation greffe | 37,45€ | Frais fixes |
| Déclaration bénéficiaires | 21,41€ | Obligatoire |
| Dépôt capital (banque) | 0€ - 100€ | Selon la banque |
| Expert-comptable (annuel) | 1 200€ - 3 600€/an | Obligatoire dans les faits |
| **TOTAL création** | **~2 000€ - 3 500€** | Hors expert-comptable |

## Option : SAS avec holding

Pour optimisation fiscale future (régime mère-fille, report d'imposition sur plus-values) :
- Créer une holding SAS qui détient les parts d'Eventy SAS
- Coût supplémentaire : ~1 500€ de création
- À envisager une fois la société rentable

## Checklist création SAS

- [ ] Rédiger les statuts (avocat ou legaltech)
- [ ] Ouvrir un compte bancaire professionnel
- [ ] Déposer le capital social
- [ ] Publier l'annonce légale
- [ ] Immatriculer au greffe (guichet unique INPI)
- [ ] Obtenir le Kbis
- [ ] Déclarer les bénéficiaires effectifs
- [ ] Choisir un expert-comptable
- [ ] Adhérer à un centre de gestion agréé

## Prestataires à contacter

### Avocats droit des sociétés / tourisme
- Tarif horaire moyen : 170€ - 475€ HT
- Forfait statuts SAS : 1 500€ - 2 000€
- **Action** : Demander 3 devis à des cabinets spécialisés tourisme

### Legaltech (option économique)
- Legalstart : ~300€ statuts + formalités
- Captain Contrat : ~250€ - 500€
- LegalPlace : ~200€ - 400€
- **Risque** : Statuts standards, pas personnalisés pour le tourisme

### Expert-comptable
- Budget : 100€ - 300€/mois
- **Action** : Chercher un cabinet connaissant le secteur tourisme

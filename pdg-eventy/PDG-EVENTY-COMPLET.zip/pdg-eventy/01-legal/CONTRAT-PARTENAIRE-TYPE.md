# Contrat-Cadre Partenaire — Eventy

> **Usage** : Modèle à adapter avec un avocat avant signature

---

## ENTRE LES SOUSSIGNÉS

**EVENTY** — SAS au capital de [X]€
Siège social : [adresse]
RCS : [ville] [numéro]
Immatriculation Atout France : IM[XXX]XXXXX
Représentée par David [NOM], en qualité de Président
Ci-après dénommée « **L'Agence** »

ET

**[NOM DU PARTENAIRE]** — [forme juridique]
Siège social : [adresse]
SIRET : [numéro]
Représentée par [NOM], en qualité de [TITRE]
Ci-après dénommé « **Le Prestataire** »

---

## ARTICLE 1 — OBJET

Le présent contrat a pour objet de définir les conditions dans lesquelles le Prestataire fournira des prestations de **[hébergement / transport / activités / restauration]** aux clients de l'Agence dans le cadre de voyages de groupe organisés.

## ARTICLE 2 — DURÉE

Le présent contrat est conclu pour une durée de **12 mois** à compter de sa signature, renouvelable par tacite reconduction par périodes successives de 12 mois, sauf dénonciation par l'une des parties avec un préavis de **3 mois**.

## ARTICLE 3 — PRESTATIONS

Le Prestataire s'engage à fournir les prestations suivantes :

| Prestation | Description | Tarif négocié |
|-----------|-------------|---------------|
| [Type 1] | [Détails] | [Prix] HT |
| [Type 2] | [Détails] | [Prix] HT |
| [Type 3] | [Détails] | [Prix] HT |

Les tarifs sont garantis pour la durée du contrat sauf hausse de TVA ou taxe de séjour.

## ARTICLE 4 — COMMISSION DE L'AGENCE

Le Prestataire accorde à l'Agence une commission de **[X]%** sur le prix HT des prestations vendues. Cette commission est :
- Déduite du prix facturé à l'Agence (prix net)
- OU versée trimestriellement par virement

## ARTICLE 5 — RÉSERVATIONS ET ANNULATIONS

### 5.1 Réservations
- Les réservations sont transmises par email ou via la plateforme Eventy
- Le Prestataire confirme sous **48h ouvrées** la disponibilité et le prix
- Une confirmation écrite vaut engagement ferme

### 5.2 Annulations par l'Agence
| Délai avant prestation | Pénalité |
|----------------------|----------|
| Plus de 30 jours | Aucune |
| 15 à 30 jours | 30% du montant |
| 7 à 14 jours | 50% du montant |
| Moins de 7 jours | 100% du montant |

### 5.3 Annulations par le Prestataire
En cas d'annulation par le Prestataire, celui-ci s'engage à :
- Proposer une alternative de qualité équivalente
- À défaut, rembourser l'intégralité des sommes versées
- Indemniser l'Agence à hauteur de 15% du montant de la prestation

## ARTICLE 6 — PAIEMENT

- Facturation à la prestation ou mensuelle selon volume
- Paiement par virement sous **30 jours** date de facture
- Pénalités de retard : 3 × taux d'intérêt légal + indemnité forfaitaire de 40€

## ARTICLE 7 — QUALITÉ DE SERVICE

Le Prestataire s'engage à :
- Maintenir le niveau de qualité décrit dans l'annexe technique
- Accueillir les clients de l'Agence avec professionnalisme
- Signaler immédiatement tout incident à l'Agence
- Accepter les enquêtes de satisfaction post-prestation

En cas de manquement répété (2+ plaintes justifiées), l'Agence se réserve le droit de suspendre le partenariat.

## ARTICLE 8 — ASSURANCE ET RESPONSABILITÉ

- Le Prestataire justifie d'une assurance RC Professionnelle en cours de validité
- Chaque partie est responsable des dommages causés par sa faute
- Le Prestataire garantit la sécurité des participants pendant ses prestations

## ARTICLE 9 — CONFIDENTIALITÉ

Les parties s'engagent à ne pas divulguer les informations commerciales (tarifs, volumes, conditions) échangées dans le cadre du présent contrat.

## ARTICLE 10 — RGPD

Les données personnelles des clients sont traitées conformément au RGPD. Le Prestataire s'engage à ne les utiliser que pour l'exécution de la prestation.

## ARTICLE 11 — RÉSILIATION

Résiliation possible :
- Par l'une ou l'autre des parties avec 3 mois de préavis
- Sans préavis en cas de faute grave (manquement à la sécurité, fraude)
- Sans préavis en cas de liquidation judiciaire

## ARTICLE 12 — LITIGES

En cas de litige, les parties s'engagent à une tentative de médiation. À défaut, les tribunaux de [VILLE] seront compétents.

---

**Fait à [VILLE], le [DATE], en deux exemplaires originaux.**

| Pour l'Agence | Pour le Prestataire |
|--------------|---------------------|
| David [NOM] — Président | [NOM] — [TITRE] |
| Signature : | Signature : |

---

> **Note** : Ce modèle doit être validé par un avocat spécialisé en droit du tourisme avant toute utilisation.

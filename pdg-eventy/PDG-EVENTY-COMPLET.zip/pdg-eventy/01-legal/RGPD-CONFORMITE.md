# Conformité RGPD — Eventy

## Obligations en tant que plateforme tech + agence

Eventy collecte et traite des données personnelles (clients, voyageurs, partenaires). Le RGPD s'applique intégralement.

## Données collectées

### Clients / Voyageurs
- Identité (nom, prénom, date de naissance)
- Contact (email, téléphone, adresse)
- Documents (passeport, CNI — pour les réservations)
- Données de paiement (via Stripe, jamais stockées directement)
- Préférences de voyage
- Données de santé (allergies, régimes — base légale : consentement explicite)

### Professionnels / Partenaires
- Identité du représentant
- Coordonnées entreprise
- SIRET, Kbis
- RIB (pour les paiements)

## Actions obligatoires

### Avant lancement
- [ ] Désigner un DPO (ou référent RGPD interne)
- [ ] Rédiger le registre des traitements
- [ ] Rédiger la politique de confidentialité (site)
- [ ] Rédiger les CGU et CGV
- [ ] Implémenter le bandeau cookies (consentement)
- [ ] Mettre en place les mentions légales
- [ ] Configurer le droit d'accès / rectification / suppression (DSAR — déjà implémenté dans le backend)
- [ ] Chiffrer les données sensibles en base
- [ ] Signer des DPA (Data Processing Agreement) avec les sous-traitants

### Sous-traitants nécessitant un DPA
- Hébergeur cloud (OVH/Scaleway/Vercel)
- Stripe (paiements)
- SendGrid / Brevo (emails)
- Google Analytics (si utilisé) ou alternative privacy-friendly
- Prestataires transport et hébergement recevant des données voyageurs

## Module DSAR (déjà dans le backend)

Le module `dsar` du backend gère :
- Demande d'accès aux données personnelles
- Demande de rectification
- Demande de suppression (droit à l'oubli)
- Export des données (portabilité)

## Durées de conservation

| Donnée | Durée | Base légale |
|--------|-------|-------------|
| Données client actif | Durée de la relation + 3 ans | Contrat |
| Données prospect | 3 ans après dernier contact | Intérêt légitime |
| Données comptables | 10 ans | Obligation légale |
| Documents voyage (passeport) | Fin du voyage + 1 an | Contrat |
| Cookies analytics | 13 mois max | Consentement |
| Logs de connexion | 1 an | Obligation légale |

## Sanctions CNIL

- Jusqu'à 20M€ ou 4% du CA mondial
- Mise en demeure publique (mauvaise publicité)

# Conditions Générales de Vente — Template Eventy

> **ATTENTION** : Ce template doit être validé par un avocat spécialisé tourisme avant publication.

## Structure des CGV (agence de voyage en ligne)

### Article 1 — Objet et champ d'application
- Définition du service Eventy (plateforme + organisation de voyages)
- Application des CGV à toute réservation effectuée sur eventy.fr

### Article 2 — Informations pré-contractuelles
- Description des prestations (transport, hébergement, activités, restauration)
- Prix total TTC, détail des composantes
- Modalités de paiement (acompte, solde, échéancier)
- Conditions de passeport, visa, santé

### Article 3 — Réservation et formation du contrat
- Processus de réservation en ligne
- Confirmation par email
- Délai de rétractation (attention : exception voyage = pas de droit de rétractation 14 jours)

### Article 4 — Prix et paiement
- Prix en euros TTC
- Acompte à la réservation (30% standard)
- Solde à J-30 avant départ
- Révision de prix possible (carburant, taxes, devises) — conditions strictes

### Article 5 — Modification par le client
- Frais de modification selon délai
- Transfert de contrat à un tiers possible (conditions)

### Article 6 — Annulation par le client
- Barème d'annulation progressif :
  - Plus de 60 jours : frais de dossier uniquement
  - 60-30 jours : 30% du prix
  - 30-15 jours : 50% du prix
  - 15-7 jours : 75% du prix
  - Moins de 7 jours : 100% du prix
- Recommandation d'assurance annulation

### Article 7 — Modification / Annulation par Eventy
- Modification mineure : information client sans indemnité
- Modification significative : droit d'annulation + remboursement intégral
- Force majeure : remboursement sans indemnité supplémentaire

### Article 8 — Responsabilité
- Responsabilité de plein droit de l'organisateur (art. L.211-16 Code du tourisme)
- Limites de responsabilité conformes aux conventions internationales
- Exclusions (faute du voyageur, tiers étranger, force majeure)

### Article 9 — Assurance
- Assurance annulation proposée (optionnelle)
- Assurance rapatriement recommandée
- RC Pro Eventy (numéro de contrat à indiquer)

### Article 10 — Réclamations
- Réclamation pendant le voyage : au représentant local
- Réclamation post-voyage : par email dans les 30 jours
- Médiation : Médiation Tourisme et Voyage (MTV)

### Article 11 — Protection des données
- Renvoi vers la politique de confidentialité
- Droits RGPD du client

### Article 12 — Droit applicable et litiges
- Droit français applicable
- Médiation avant toute action judiciaire
- Tribunal compétent

### Mentions obligatoires à inclure
- Numéro d'immatriculation Atout France
- Nom et coordonnées du garant financier (APST ou autre)
- Nom et numéro de police RC Pro
- SIRET, RCS, capital social

## Budget avocat pour CGV

- Rédaction CGV agence de voyage : 1 500€ - 3 000€
- Pack complet (CGV + CGU + mentions légales + politique confidentialité) : 2 500€ - 5 000€
- À privilégier : avocat spécialisé droit du tourisme

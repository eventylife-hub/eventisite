# Immatriculation Atout France — Eventy

## Obligation légale

Toute entreprise organisant ou commercialisant des voyages et séjours en France doit être immatriculée au registre d'Atout France. Sans immatriculation = activité illégale.

## Pré-requis (dans cet ordre)

1. **Société créée** — Kbis obtenu
2. **Garantie financière souscrite** — attestation APST ou assureur (voir `../08-assurance-conformite/GARANTIE-FINANCIERE.md`)
3. **RC Pro souscrite** — attestation assureur (voir `../08-assurance-conformite/RC-PRO.md`)

## Pièces justificatives du dossier

- [ ] Extrait Kbis de moins de 3 mois
- [ ] Copie certifiée des statuts
- [ ] Attestation de garantie financière
- [ ] Attestation d'assurance RC Pro
- [ ] Compte de résultat prévisionnel
- [ ] Tableau de volume d'affaires prévisionnel
- [ ] Descriptif détaillé du projet (activité, cible, fonctionnement plateforme)
- [ ] Justificatif de capacité professionnelle du dirigeant

## Capacité professionnelle

Depuis 2016, pas de diplôme obligatoire. Mais il faut prouver une capacité professionnelle par l'un de ces moyens :
- Diplôme BTS Tourisme ou équivalent
- Expérience professionnelle d'1 an (à temps plein) dans le secteur
- Expérience de 3 ans dans un autre secteur + formation

## Procédure

1. Déposer le dossier complet sur le site Atout France
2. Récépissé envoyé à réception
3. Passage en commission dans le mois
4. Absence de réponse à 1 mois = acceptation tacite
5. Attribution d'un numéro d'immatriculation IM0XXXXXXX

## Coût

- **Frais d'immatriculation : 0€** (supprimés depuis 2019)
- Renouvellement obligatoire tous les 3 ans

## Numéro à afficher

Le numéro d'immatriculation doit figurer sur :
- Le site web (footer, mentions légales, page contact)
- Tous les documents commerciaux (devis, factures, contrats)
- Les emails commerciaux
- Les CGV

## Sanctions

- Exercice sans immatriculation : jusqu'à 1 an d'emprisonnement + 15 000€ d'amende
- Radiation possible si conditions non respectées

## Timeline estimée

| Étape | Durée |
|-------|-------|
| Obtenir garantie financière | 2-4 semaines |
| Obtenir RC Pro | 1-2 semaines |
| Préparer le dossier | 1 semaine |
| Réponse Atout France | 1 mois max |
| **TOTAL** | **6-10 semaines** |

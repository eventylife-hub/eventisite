# Checklist Avocat — Eventy

## Profil recherché

- Spécialisé **droit du tourisme** (idéalement)
- Ou droit des affaires + connaissance réglementaire voyages
- Basé en France, barreaux Paris/Lyon de préférence

## Missions à confier

### Phase 1 — Création (Budget : 1 500€ - 3 000€)

- [ ] Rédaction des statuts SAS personnalisés
- [ ] Clause de gouvernance (président unique)
- [ ] Clause d'agrément (si futurs associés)
- [ ] Vérification conformité activité tourisme
- [ ] Conseil sur le régime fiscal optimal

### Phase 2 — CGV/CGU (Budget : 2 500€ - 5 000€)

- [ ] Rédaction CGV conforme Code du Tourisme
- [ ] Rédaction CGU plateforme web
- [ ] Politique de confidentialité (RGPD)
- [ ] Mentions légales du site
- [ ] Conditions d'utilisation espace pro (B2B)
- [ ] Contrat-type partenaire (hébergement, activités)
- [ ] Clause de médiation obligatoire

### Phase 3 — Suivi (Budget : 500€ - 1 000€/an)

- [ ] Relecture annuelle CGV
- [ ] Conseil ponctuel (réclamation, litige)
- [ ] Veille réglementaire tourisme

## Questions à poser lors du premier RDV

1. Avez-vous déjà accompagné des agences de voyages en ligne ?
2. Connaissez-vous les obligations Atout France ?
3. Quelle est votre expérience avec le Code du Tourisme ?
4. Proposez-vous un forfait création + CGV ?
5. Quel est votre délai pour la rédaction des statuts ?
6. Pouvez-vous gérer le dépôt au greffe ?

## Cabinets recommandés à contacter

| Cabinet | Spécialité | Localisation | Contact |
|---------|-----------|-------------|---------|
| Rechercher sur avocats-tourisme.fr | Droit tourisme | Paris | Site spécialisé |
| Legalstart / Captain Contrat | Création SAS | En ligne | legalstart.fr |
| Avocat local spécialisé | Droit des affaires | À trouver | Barreau local |

## Documents à préparer pour le RDV

- [ ] Business plan résumé (1 page)
- [ ] Description de l'activité Eventy
- [ ] Maquette du site (captures d'écran)
- [ ] Flux financier type (client → Eventy → prestataires)
- [ ] Liste des partenaires envisagés
- [ ] Copie du budget prévisionnel

# Mentions Légales & Politique de Confidentialité — eventy.life

> **Usage** : À adapter puis publier sur le site web (obligations légales)

---

## 1. Mentions légales (LCEN — Art. 6 Loi n°2004-575)

### Éditeur du site
- **Raison sociale** : EVENTY — SAS au capital de [X]€
- **Siège social** : [adresse complète]
- **RCS** : [Ville] B [numéro]
- **SIRET** : [numéro]
- **TVA intracommunautaire** : FR[XX] [numéro]
- **Président** : David [NOM]
- **Email** : contact@eventy.life
- **Téléphone** : [numéro]

### Immatriculation tourisme
- **Immatriculation Atout France** : IM[XXX]XXXXX
- **Garantie financière** : APST — 15 avenue Carnot, 75017 Paris
- **Assurance RC Pro** : [Assureur], Police n°[XXX]

### Hébergeur du site
- **Nom** : [Vercel / OVH / AWS]
- **Adresse** : [adresse hébergeur]
- **Téléphone** : [numéro]

### Directeur de la publication
- David [NOM], Président

---

## 2. Conditions d'utilisation

L'utilisation du site eventy.life implique l'acceptation des présentes conditions. Eventy se réserve le droit de modifier ces conditions à tout moment.

### Propriété intellectuelle
L'ensemble du contenu du site (textes, images, logo, code, design) est protégé par le droit d'auteur. Toute reproduction sans autorisation écrite est interdite.

### Responsabilité
Eventy s'efforce de fournir des informations exactes et à jour. Toutefois, des erreurs ou omissions peuvent survenir. Eventy ne saurait être tenue responsable de l'utilisation des informations publiées.

---

## 3. Politique de confidentialité (RGPD)

### Responsable de traitement
EVENTY — SAS — contact@eventy.life

### Données collectées

| Donnée | Finalité | Base légale | Durée conservation |
|--------|----------|-------------|-------------------|
| Nom, prénom | Gestion réservation | Contrat | 3 ans après dernier voyage |
| Email | Communication, devis | Consentement / Contrat | 3 ans après dernier contact |
| Téléphone | Contact urgent voyage | Contrat | 3 ans |
| Adresse | Facturation | Obligation légale | 10 ans (comptable) |
| Pièce d'identité | Réservation transport/hôtel | Contrat | Suppression à J+30 |
| Données bancaires | Paiement Stripe | Contrat | Non stockées (Stripe PCI-DSS) |
| Cookies | Analyse audience | Consentement | 13 mois maximum |

### Droits des utilisateurs (RGPD Art. 15-22)
- **Accès** : Obtenir une copie de vos données
- **Rectification** : Corriger des données inexactes
- **Suppression** : Demander l'effacement (droit à l'oubli)
- **Portabilité** : Recevoir vos données dans un format structuré
- **Opposition** : Refuser le traitement à des fins de prospection
- **Limitation** : Geler le traitement de vos données

**Exercice des droits** : privacy@eventy.life ou courrier au siège social
**Délai de réponse** : 30 jours maximum
**Réclamation** : CNIL — www.cnil.fr

### Cookies

| Cookie | Finalité | Durée | Obligatoire |
|--------|----------|-------|-------------|
| session_id | Authentification | Session | Oui (fonctionnel) |
| consent | Choix cookies | 13 mois | Oui (fonctionnel) |
| _ga, _gid | Google Analytics | 13 mois | Non (consentement) |
| stripe_* | Paiement sécurisé | Session | Oui (fonctionnel) |

Refus des cookies optionnels : via le bandeau cookies ou paramètres navigateur.

### Sous-traitants

| Sous-traitant | Finalité | Localisation | Garanties |
|--------------|----------|-------------|-----------|
| Stripe | Paiement | UE/US | SCC + PCI-DSS |
| [Hébergeur] | Hébergement données | France / UE | ISO 27001 |
| Google Analytics | Statistiques | US | SCC |
| Brevo/Mailjet | Emails transactionnels | France | RGPD-compliant |

### Sécurité
- Chiffrement HTTPS (TLS 1.3) sur toutes les pages
- Mots de passe hashés (bcrypt, salt unique)
- JWT avec rotation régulière des secrets
- Rate limiting anti-bruteforce
- Données bancaires jamais stockées (Stripe tokenisation)
- Audits de sécurité réguliers du code backend

---

## 4. Médiateur du tourisme

Conformément à l'article L.612-1 du Code de la consommation :
- **Médiateur** : Médiation Tourisme et Voyage (MTV)
- **Site** : www.mtv.travel
- **Adresse** : BP 80 303, 75823 Paris Cedex 17

---

> **Note** : Ces mentions doivent être validées par un avocat et publiées de manière accessible sur le site (lien en footer obligatoire).

# Templates Emails — Partenaires

## 1. Premier contact — Hébergement

**Objet** : Partenariat hébergement de groupe — Eventy

---

Bonjour [Nom du responsable],

Je suis David, fondateur d'Eventy, une agence de voyages spécialisée dans l'organisation de séjours de groupe (team buildings, séminaires, groupes d'amis de 15 à 50 personnes).

Nous recherchons des partenaires hébergement de qualité dans votre région pour proposer à nos clients des expériences mémorables.

**Ce que nous proposons :**
- Des réservations régulières de groupes (week-ends et semaines)
- Un interlocuteur unique qui gère toute l'organisation
- Paiement garanti sous 30 jours après le séjour
- Visibilité sur notre plateforme eventy.fr

**Ce que nous recherchons :**
- Capacité d'accueil groupe : 15 à 50 personnes
- Tarifs préférentiels groupe (à discuter)
- Disponibilité pour une visite ou un appel découverte

Seriez-vous disponible pour un échange de 15 minutes cette semaine ou la semaine prochaine ?

Cordialement,
David
Fondateur — Eventy
contact@eventy.fr | eventy.fr

---

## 2. Premier contact — Activités / Loisirs

**Objet** : Partenariat activités de groupe — Eventy

---

Bonjour [Nom],

Je suis David, fondateur d'Eventy, plateforme spécialisée dans les voyages de groupe (team buildings, séminaires, groupes d'amis).

Nous organisons des séjours incluant des activités variées et nous cherchons des prestataires fiables dans votre domaine.

**Notre besoin :**
- Activités adaptées aux groupes de 15 à 50 personnes
- Disponibilité week-ends et en semaine
- Possibilité de privatisation
- Tarifs groupe négociés

**En contrepartie, nous vous apportons :**
- Un volume régulier de participants
- Gestion complète des inscriptions et paiements
- Mise en avant sur notre site et réseaux sociaux

Pourrions-nous échanger cette semaine pour discuter d'un partenariat ?

Cordialement,
David
Fondateur — Eventy
contact@eventy.fr

---

## 3. Premier contact — Transport / Autocariste

**Objet** : Demande de tarifs transport de groupe — Eventy

---

Bonjour,

Je suis David, fondateur d'Eventy, agence de voyages spécialisée dans les séjours de groupe.

Nous recherchons un partenaire transport fiable pour assurer les déplacements de nos groupes (15 à 55 personnes) sur des trajets régionaux et nationaux.

**Nos besoins typiques :**
- Véhicules : minibus 20 places à autocar 55 places
- Fréquence : 2 à 5 prestations/mois à terme
- Trajets : 100 à 600 km aller-retour
- Durée : 1 à 5 jours

**Pourriez-vous nous transmettre :**
1. Votre grille tarifaire (prix/jour + prix/km)
2. Vos conditions pour les réservations régulières
3. Votre politique d'annulation
4. Vos disponibilités pour les 3 prochains mois

Je suis disponible pour un appel à votre convenance.

Cordialement,
David
Fondateur — Eventy
contact@eventy.fr

---

## 4. Relance J+7

**Objet** : Relance — Partenariat Eventy

---

Bonjour [Nom],

Je me permets de revenir vers vous suite à mon email du [date].

Eventy organise des séjours de groupe et nous serions ravis de collaborer avec [Nom établissement]. Même un rapide échange téléphonique de 10 minutes nous permettrait de voir si un partenariat fait sens.

Seriez-vous disponible cette semaine ?

Cordialement,
David — Eventy

---

## 5. Demande de devis fournisseur

**Objet** : Demande de devis — Groupe [X] personnes, [dates]

---

Bonjour [Nom],

Suite à notre échange, pourriez-vous nous établir un devis pour :

- **Dates** : du [date début] au [date fin]
- **Participants** : [nombre] personnes
- **Prestations souhaitées** :
  - [Détailler : chambres, repas, activités, transport]
- **Budget indicatif** : [fourchette si applicable]

Merci de nous transmettre le devis avant le [date limite] pour intégration dans notre offre client.

Cordialement,
David — Eventy

---

## 6. Confirmation de réservation partenaire

**Objet** : Confirmation de réservation — Groupe Eventy du [dates]

---

Bonjour [Nom],

Je vous confirme la réservation suivante :

| Détail | Information |
|--------|-----------|
| Référence Eventy | [REF-XXXXX] |
| Dates | [dates] |
| Nombre de personnes | [X] |
| Prestations | [détail] |
| Montant HT | [montant]€ |
| Conditions de paiement | Virement 30 jours après séjour |

**Contact sur place** : David — [téléphone]

Merci de me confirmer la bonne réception de cette réservation.

Cordialement,
David — Eventy

---

## 7. Email post-séjour partenaire

**Objet** : Retour séjour du [dates] — Merci !

---

Bonjour [Nom],

Le séjour du [dates] avec le groupe de [X] personnes s'est bien déroulé, merci pour la qualité de vos prestations !

**Retour rapide :**
- Points positifs : [à compléter]
- Points d'amélioration : [à compléter]

Le règlement sera effectué sous 30 jours selon nos conditions habituelles.

Nous avons d'ores et déjà [X] demandes pour les prochains mois dans votre région. Souhaitez-vous qu'on bloque des dates ?

Cordialement,
David — Eventy

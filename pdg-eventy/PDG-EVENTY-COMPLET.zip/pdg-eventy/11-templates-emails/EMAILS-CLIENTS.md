# Templates Emails — Clients

## 1. Accusé de réception demande de devis

**Objet** : Votre demande de voyage de groupe — Eventy

---

Bonjour [Prénom],

Merci pour votre demande ! Nous sommes ravis de votre intérêt pour un voyage de groupe avec Eventy.

**Récapitulatif de votre demande :**
- Type de voyage : [week-end / séjour court / semaine]
- Nombre de participants : [X] personnes
- Dates souhaitées : [dates]
- Destination / région : [destination]
- Budget indicatif : [budget]

Notre équipe prépare votre devis personnalisé. Vous le recevrez **sous 48 heures maximum**.

En attendant, n'hésitez pas à nous contacter si vous avez des questions.

À très vite,
David — Eventy
contact@eventy.fr

---

## 2. Envoi de devis

**Objet** : Votre devis personnalisé — [Type voyage] [Destination]

---

Bonjour [Prénom],

Votre devis est prêt ! Voici le programme que nous avons conçu pour votre groupe :

**[Titre du voyage]**
📅 Du [date] au [date]
👥 [X] participants
📍 [Destination]

**Le programme inclut :**
- [Hébergement : détail]
- [Activités : détail]
- [Transport : détail]
- [Repas : détail]

**Tarif : [montant]€ par personne** (tout compris)
Soit [montant total]€ pour le groupe.

**Ce tarif comprend :**
- Hébergement [X] nuits
- [X] activités encadrées
- Transport aller-retour en [véhicule]
- [Repas inclus]
- Assurance annulation
- Coordination Eventy de A à Z

**Prochaines étapes :**
1. Valider le devis (réponse par email)
2. Verser l'acompte de 30% pour confirmer
3. Nous gérons tout le reste !

Le devis est valable 15 jours. N'hésitez pas si vous souhaitez ajuster le programme.

Cordialement,
David — Eventy

---

## 3. Relance devis J+5

**Objet** : Avez-vous eu le temps de consulter votre devis ? — Eventy

---

Bonjour [Prénom],

Je me permets de revenir vers vous concernant le devis envoyé le [date] pour votre [type de voyage] à [destination].

Avez-vous eu l'occasion de le consulter ? Je suis disponible pour en discuter ou ajuster le programme selon vos souhaits.

À bientôt,
David — Eventy

---

## 4. Confirmation de réservation

**Objet** : Réservation confirmée ! — [Voyage] [Dates]

---

Bonjour [Prénom],

Excellente nouvelle, votre voyage est confirmé ! 🎉

**Récapitulatif :**
| Détail | Information |
|--------|-----------|
| Référence | EVT-[XXXXX] |
| Voyage | [Titre] |
| Dates | [dates] |
| Participants | [X] personnes |
| Montant total | [montant]€ |
| Acompte versé | [montant]€ (30%) |
| Solde restant | [montant]€ |
| Date limite solde | [date J-30] |

**Prochaines étapes :**
- J-30 : Nous vous demanderons le solde du paiement
- J-15 : Vous recevrez tous les documents de voyage (programme détaillé, convocation, infos pratiques)
- J-3 : Rappel avec point de rendez-vous et horaires définitifs
- Jour J : Votre coordinateur Eventy sera joignable en permanence

En cas de question : contact@eventy.fr ou [téléphone]

Hâte d'organiser ce super moment pour votre groupe !

David — Eventy

---

## 5. Demande de solde J-30

**Objet** : Rappel — Solde de votre voyage [Référence]

---

Bonjour [Prénom],

Votre voyage approche ! Il reste **30 jours** avant le départ.

Conformément à nos conditions, le solde de votre réservation est à régler avant le [date] :

- **Montant restant** : [montant]€
- **Mode de paiement** : Virement bancaire / CB sur votre espace client
- **Référence** : EVT-[XXXXX]

**Coordonnées bancaires :**
[À compléter une fois le compte ouvert]

Merci de nous confirmer le paiement par retour d'email.

Cordialement,
David — Eventy

---

## 6. Documents de voyage J-15

**Objet** : Vos documents de voyage — Départ le [date]

---

Bonjour [Prénom],

Plus que 15 jours avant le grand départ ! Voici tous les documents pour votre voyage :

📋 **Programme détaillé** : [lien ou PJ]
📍 **Convocation** : Rendez-vous le [date] à [heure] à [lieu]
📱 **Contact d'urgence** : David — [téléphone] (joignable 24h pendant le séjour)

**À prévoir :**
- [Liste selon le type de voyage]
- Pièce d'identité valide
- Carte européenne d'assurance maladie (si applicable)

**Rappel assurance :** Votre voyage inclut l'assurance [annulation / rapatriement / les deux].

N'hésitez pas à transmettre ces informations à tous les participants de votre groupe.

Bon voyage !
David — Eventy

---

## 7. Enquête satisfaction J+3

**Objet** : Comment s'est passé votre voyage ? — Eventy

---

Bonjour [Prénom],

J'espère que votre [type de voyage] à [destination] vous a plu !

Votre avis nous est précieux pour améliorer nos services. Pourriez-vous prendre 2 minutes pour répondre à ces quelques questions ?

**[Lien vers formulaire de satisfaction]**

En remerciement, vous bénéficierez de **5% de réduction** sur votre prochain voyage Eventy.

Merci d'avance !
David — Eventy

---

## 8. Relance avis en ligne J+7

**Objet** : Un petit mot pour nous ? ⭐

---

Bonjour [Prénom],

Si votre voyage vous a plu, un avis sur [Google / TripAdvisor] nous aiderait énormément à nous faire connaître :

**[Lien direct vers la page d'avis]**

Cela ne prend que 30 secondes et c'est la meilleure façon de nous soutenir. Merci ! 🙏

David — Eventy

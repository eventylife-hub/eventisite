# Templates Emails — Administratif & Institutionnel

## 1. Contact APST — Demande d'adhésion

**Objet** : Demande d'adhésion — Agence de voyages en création

---

Madame, Monsieur,

Je suis David, fondateur d'Eventy, une agence de voyages en cours de création spécialisée dans l'organisation de séjours de groupe (team buildings, séminaires, voyages entre amis).

Je souhaite adhérer à l'APST pour la garantie financière obligatoire prévue par l'article L.211-18 du Code du Tourisme.

**Informations sur notre activité :**
- Forme juridique : SAS (en cours de création)
- Activité : Organisation et vente de voyages de groupe en France
- CA prévisionnel année 1 : [montant]€
- Fonctionnement : Plateforme web + conseil personnalisé

Pourriez-vous m'adresser :
1. Le dossier de candidature
2. La liste des pièces justificatives requises
3. Le calendrier des prochaines commissions d'adhésion

Je reste à votre disposition pour tout complément d'information.

Cordialement,
David
Fondateur — Eventy
[email] | [téléphone]

---

## 2. Contact assureur RC Pro

**Objet** : Demande de devis RC Pro — Agence de voyages

---

Bonjour,

Je crée une agence de voyages (SAS) spécialisée dans les séjours de groupe et je recherche une assurance Responsabilité Civile Professionnelle conforme aux obligations du Code du Tourisme.

**Profil de l'agence :**
- Activité : Organisation de voyages de groupe en France
- CA prévisionnel année 1 : [montant]€
- Nombre de voyageurs estimé : [X] par an
- Types de prestations : hébergement, transport, activités, restauration
- Fonctionnement : 100% en ligne + coordination terrain

**Couverture recherchée :**
- RC Pro agence de voyages (minimum 300 000€)
- Erreur, omission, défaut de conseil
- Annulation de prestation
- Dommages pendant le voyage

Pourriez-vous me transmettre un devis ?

Cordialement,
David — Eventy

---

## 3. Contact banque pro

**Objet** : Ouverture de compte professionnel — SAS Eventy

---

Bonjour,

Je souhaite ouvrir un compte professionnel pour ma société SAS Eventy, agence de voyages en création.

**Informations :**
- Forme juridique : SAS (capital [montant]€)
- Activité : Organisation de séjours de groupe
- Besoin : Compte courant pro + terminal CB (via Stripe)
- Volume estimé : [X] transactions/mois à terme
- Besoins spécifiques : Virements SEPA fournisseurs, rapprochement bancaire

Pourriez-vous me confirmer :
1. Les documents nécessaires pour l'ouverture
2. Le délai de traitement
3. Vos offres adaptées aux startups

Cordialement,
David — Eventy

---

## 4. Contact expert-comptable

**Objet** : Recherche expert-comptable — Agence de voyages SAS

---

Bonjour,

Je crée une agence de voyages (SAS) et je recherche un expert-comptable pour m'accompagner dès la création.

**Missions souhaitées :**
- Conseil sur le choix du régime fiscal (IS)
- Tenue de la comptabilité mensuelle
- Déclarations fiscales et sociales
- Bilan annuel et liasse fiscale
- Conseil sur la rémunération du dirigeant

**Particularités de l'activité :**
- Encaissement pour le compte de tiers (clients → prestataires)
- Gestion des acomptes et soldes
- TVA sur marge (régime agences de voyages, art. 266-1-e du CGI)
- Volume faible année 1 (~[X] voyages/mois)

Quel serait votre tarif pour ce type de mission ?

Cordialement,
David — Eventy

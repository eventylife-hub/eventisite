# Dossier de Présentation — Demande de Compte Pro & Financement

> **Destinataire** : Banquier / Conseiller professionnel

---

## 1. Présentation du projet

**Nom** : EVENTY
**Activité** : Plateforme digitale d'organisation de voyages de groupe
**Forme juridique** : SAS (en cours de création)
**Fondateur** : David — Développeur & entrepreneur
**Domaine** : eventy.life

### Le concept
Eventy est une plateforme technologique tout-en-un qui simplifie l'organisation de voyages de groupe : devis en ligne, paiement partagé, gestion logistique automatisée. Nous combinons la technologie SaaS avec l'activité réglementée d'agence de voyages.

### Le marché
- Marché français du tourisme de groupe : ~8 milliards €/an
- Croissance post-COVID : +12% annuel sur le segment groupe
- Cible : groupes d'amis (25-45 ans), familles, associations, entreprises (CE, séminaires)
- Tendance : digitalisation croissante — les agences traditionnelles n'ont pas d'outil en ligne performant

---

## 2. Avantage concurrentiel

| Critère | Agences traditionnelles | Eventy |
|---------|------------------------|--------|
| Devis | 48-72h par email | Instantané en ligne |
| Paiement groupe | Virement unique (1 personne paie) | Split payment (chacun paie sa part) |
| Suivi | Appels + emails | Dashboard temps réel |
| Réservation | Formulaire papier/email | 100% digital, mobile |
| Automatisation | Manuelle | Backend 37 modules, 3 300+ tests |

**Barrière à l'entrée** : Plateforme développée en interne (290 000+ lignes de code), non reproductible facilement.

---

## 3. Modèle économique

### Sources de revenus
1. **Commission sur ventes** : 8-25% selon prestation (hébergement, transport, activités)
2. **Frais de dossier** : 25-50€ par réservation
3. **Revenus SaaS** (Phase 2) : abonnements Pro 29-99€/mois

### Exemple unitaire — Voyage groupe 15 personnes (3J/2N)

| Poste | CA TTC | Marge |
|-------|--------|-------|
| Hébergement | 1 800€ | 216€ (12%) |
| Transport | 750€ | 75€ (10%) |
| Activités | 1 200€ | 240€ (20%) |
| Restauration | 1 500€ | 180€ (12%) |
| Assurance | 225€ | 56€ (25%) |
| Frais de dossier | 525€ | 525€ (100%) |
| **Total** | **6 000€** | **1 292€ (21,5%)** |

---

## 4. Prévisionnel financier (Year 1)

| Indicateur | M1-M3 | M4-M6 | M7-M12 | Total Y1 |
|-----------|-------|-------|--------|----------|
| Voyages/mois | 1 | 2-3 | 4-6 | ~40 |
| CA moyen/voyage | 5 000€ | 6 000€ | 8 000€ | |
| **CA total** | 15 000€ | 42 000€ | 144 000€ | **~200 000€** |
| Marge brute (~20%) | 3 000€ | 8 400€ | 28 800€ | **~40 000€** |
| Charges fixes/mois | 1 500€ | 2 000€ | 3 000€ | **~28 000€** |
| **Résultat net** | -1 500€ | +2 400€ | +10 800€ | **~12 000€** |

### Charges fixes mensuelles (Phase 1)

| Poste | Montant/mois |
|-------|-------------|
| Hébergement cloud | 25-85€ |
| Assurance RC Pro | 65-170€ |
| Garantie APST | 175€ |
| Comptabilité | 150-300€ |
| Marketing digital | 200-500€ |
| Téléphone/internet | 50€ |
| Logiciels (Stripe, emails) | 50€ |
| **Total** | **~750-1 300€** |

---

## 5. Besoins de financement

### Investissement initial

| Poste | Montant |
|-------|---------|
| Création SAS (frais juridiques) | 2 000-3 500€ |
| Garantie financière APST (caution) | 2 100€/an |
| RC Pro (prime annuelle) | 800-2 000€ |
| Immatriculation Atout France | ~200€ |
| Développement plateforme | 0€ (développé par le fondateur) |
| Marketing lancement | 1 500-3 000€ |
| Trésorerie de démarrage (3 mois) | 5 000€ |
| **TOTAL** | **~12 000-16 000€** |

### Demande à la banque
- **Compte professionnel SAS** avec CB et terminal Stripe
- **Ligne de découvert** : 3 000-5 000€ (couverture décalage trésorerie acompte/prestataire)
- **Prêt professionnel** (optionnel) : 10 000-15 000€ sur 36 mois pour couvrir les coûts de lancement

### Garanties proposées
- Apport personnel : [X]€
- Développement plateforme valorisé à 50 000€+ (290 000 lignes de code)
- Garantie BPI France (prêt d'honneur possible via Réseau Entreprendre / Initiative France)

---

## 6. Conformité réglementaire

| Obligation | Statut | Preuve |
|-----------|--------|--------|
| Immatriculation Atout France | En préparation | Dossier en cours |
| Garantie financière APST | En préparation | Dossier déposé |
| RC Professionnelle | En préparation | Devis obtenus |
| Conformité RGPD | Implémenté | Module backend dédié |
| CGV conformes | Rédigées | Template validé |
| Médiation tourisme MTV | Prévu | Adhésion au lancement |

---

## 7. Calendrier

| Étape | Délai |
|-------|-------|
| Création SAS + compte pro | Semaine 1-2 |
| Dépôt garantie APST | Semaine 2-4 |
| Souscription RC Pro | Semaine 2-3 |
| Dossier Atout France | Semaine 4-6 |
| Mise en production site | Semaine 6-8 |
| Premier voyage organisé | Semaine 8-12 |
| Point d'équilibre | Mois 4-6 |

---

## 8. Pourquoi investir dans Eventy

1. **Marché porteur** : tourisme de groupe en croissance, digitalisation en retard
2. **Produit prêt** : 290 000+ lignes de code, 37 modules, 3 300+ tests
3. **Coûts faibles** : tech développée en interne, charges fixes < 1 500€/mois
4. **Scalable** : la plateforme peut gérer 100x le volume sans coûts proportionnels
5. **Réglementaire** : toutes les obligations identifiées et en cours de traitement
6. **Fondateur engagé** : compétences techniques + connaissance métier

---

> **Contact** : David — eventylife@gmail.com — eventy.life

# Stratégie Partenaires — Eventy

## Types de partenaires nécessaires

### Priorité 1 — Indispensables (avant lancement)

| Type | Besoin | Nombre min | Critères |
|------|--------|-----------|----------|
| Autocaristes | Transport groupe | 2-3 | Prix, fiabilité, couverture France |
| Hôtels / Gîtes | Hébergement | 5-10 | Rapport qualité/prix, capacité groupe |
| Restaurants | Restauration | 5-10 | Menus groupe, flexibilité |
| Activités / Loisirs | Programme | 5-10 | Originalité, sécurité, prix |

### Priorité 2 — Croissance (mois 3-6)

| Type | Besoin | Nombre min |
|------|--------|-----------|
| Tour-opérateurs | Packages vols + hôtels | 1-2 |
| Assureurs voyage | Assurance client | 1 |
| Guides locaux | Accompagnement | 3-5 |
| Prestataires événementiels | Team building, soirées | 3-5 |

### Priorité 3 — Scale (mois 6+)

| Type | Besoin |
|------|--------|
| Compagnies aériennes | Vols directs |
| Offices de tourisme | Partenariats destination |
| Entreprises (B2B) | Séminaires, CE |

---

## Grille d'évaluation partenaire

Note sur 5 pour chaque critère :

| Critère | Poids | Description |
|---------|-------|-------------|
| Prix | 25% | Compétitivité des tarifs |
| Fiabilité | 25% | Ponctualité, respect engagements |
| Qualité | 20% | Niveau de prestation |
| Flexibilité | 15% | Capacité d'adaptation (annulation, modif) |
| Communication | 10% | Réactivité, outils de suivi |
| RSE | 5% | Engagement environnemental |

**Score minimum pour partenariat** : 3,5/5

---

## Process de sélection

1. **Identification** — Recherche web, recommandations, salons pro
2. **Premier contact** — Email de présentation (template ci-dessous)
3. **Demande de devis** — Sur cas concret (weekend type 15 pers.)
4. **Comparaison** — Grille d'évaluation
5. **Négociation** — Contrat cadre avec volumes prévisionnels
6. **Test** — Premier voyage réel pour évaluer
7. **Validation** — Intégration dans le catalogue Eventy

---

## Templates emails

### Email de premier contact — Hébergement

```
Objet : Partenariat Eventy — Voyages de groupe [Nom établissement]

Bonjour [Prénom],

Je suis David, fondateur d'Eventy, une plateforme de voyages de groupe en cours de lancement.

Nous organisons des séjours pour des groupes de 10 à 50 personnes (amis, familles, associations, entreprises) partout en France. Votre établissement correspond parfaitement à notre positionnement.

Nous recherchons des partenaires hébergement de confiance avec :
- Tarifs groupe préférentiels
- Capacité d'accueil 10+ chambres
- Flexibilité sur les dates et modifications

En retour, nous vous apportons :
- Un flux régulier de réservations (objectif 2-5 groupes/mois à 6 mois)
- Visibilité sur notre plateforme (fiche partenaire dédiée)
- Paiement garanti sous 30 jours

Seriez-vous disponible pour échanger la semaine prochaine ?

Cordialement,
David — Eventy
eventylife@gmail.com
```

### Email de relance (J+7)

```
Objet : Relance — Proposition de partenariat Eventy

Bonjour [Prénom],

Je me permets de revenir vers vous suite à mon email du [date].

Nous avons déjà un premier voyage en préparation pour [mois] avec un groupe de [X] personnes et cherchons activement un partenaire hébergement dans votre région.

Seriez-vous intéressé(e) par un rapide échange téléphonique de 15 minutes ?

Je suis disponible [créneaux].

Bien cordialement,
David — Eventy
```

### Email de demande de devis

```
Objet : Demande de devis groupe — [X] personnes, [dates]

Bonjour [Prénom],

Suite à notre échange, voici les détails pour notre premier devis :

- Nombre de personnes : [X]
- Dates souhaitées : du [date] au [date]
- Chambres : [X] doubles + [X] singles
- Petit-déjeuner : inclus
- Demi-pension : à chiffrer en option
- Salle de réunion : [oui/non]

Pourriez-vous nous faire parvenir un devis détaillé ?

Merci par avance,
David — Eventy
```

---

## Suivi partenaires (à maintenir)

| Partenaire | Type | Région | Contact | Statut | Score | Notes |
|-----------|------|--------|---------|--------|-------|-------|
| _À compléter_ | | | | Prospect | /5 | |

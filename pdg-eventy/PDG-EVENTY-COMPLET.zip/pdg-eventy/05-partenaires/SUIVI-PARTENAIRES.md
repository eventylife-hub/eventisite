# Suivi Partenaires — Eventy

## Tableau de suivi

### Hébergement

| # | Nom | Type | Région | Capacité | Tarif/nuit groupe | Contact | Statut | Relance | Notes |
|---|------|------|--------|----------|------------------|---------|--------|---------|-------|
| 1 | | Hôtel ★★★ | | | €/pers | | À contacter | | |
| 2 | | Gîte | | | €/pers | | À contacter | | |
| 3 | | Hôtel ★★ | | | €/pers | | À contacter | | |
| 4 | | Résidence | | | €/pers | | À contacter | | |
| 5 | | Camping premium | | | €/pers | | À contacter | | |

### Activités & Loisirs

| # | Nom | Activité | Région | Capacité max | Tarif groupe | Contact | Statut | Relance | Notes |
|---|------|----------|--------|-------------|-------------|---------|--------|---------|-------|
| 1 | | Randonnée guidée | | | €/pers | | À contacter | | |
| 2 | | Accrobranche | | | €/pers | | À contacter | | |
| 3 | | Kayak/Rafting | | | €/pers | | À contacter | | |
| 4 | | Escape game | | | €/pers | | À contacter | | |
| 5 | | Visite culturelle | | | €/pers | | À contacter | | |

### Transport

| # | Nom | Type véhicule | Zone | Prix/jour | Prix/km | Contact | Statut | Relance | Notes |
|---|------|--------------|------|-----------|---------|---------|--------|---------|-------|
| 1 | | Autocar 49pl | | €/j | €/km | | À contacter | | |
| 2 | | Minibus 20pl | | €/j | €/km | | À contacter | | |
| 3 | | Autocar 55pl | | €/j | €/km | | À contacter | | |

### Restauration

| # | Nom | Type | Région | Capacité | Tarif menu groupe | Contact | Statut | Notes |
|---|------|------|--------|----------|------------------|---------|--------|-------|
| 1 | | Restaurant | | | €/pers | | À contacter | |
| 2 | | Traiteur | | | €/pers | | À contacter | |
| 3 | | Ferme-auberge | | | €/pers | | À contacter | |

---

## Statuts possibles

| Statut | Signification |
|--------|--------------|
| À contacter | Pas encore contacté |
| Email envoyé | Premier contact envoyé |
| Relancé | Relance J+7 envoyée |
| En discussion | Échange en cours |
| Devis reçu | Tarifs communiqués |
| Accord de principe | Accord verbal/email |
| Contrat signé | Partenariat formalisé |
| Refusé | Pas intéressé |
| Injoignable | Pas de réponse après 3 relances |

---

## Objectifs

| Période | Hébergement | Activités | Transport | Restauration |
|---------|------------|-----------|-----------|-------------|
| M0-M1 | 3 contactés | 3 contactés | 2 contactés | 1 contacté |
| M1-M2 | 5 devis reçus | 5 devis reçus | 3 devis reçus | 2 devis reçus |
| M2-M3 | 3 accords | 3 accords | 2 accords | 1 accord |
| Lancement | 5 partenaires actifs | 5 partenaires actifs | 2 partenaires actifs | 2 partenaires actifs |

# DASHBOARD PDG — Eventy

> **Dernière mise à jour** : 5 mars 2026
> **PDG** : David — eventylife@gmail.com
> **Activité** : Plateforme SaaS + Agence de voyages de groupe

---

## Statut global — 30 fichiers / 14 dossiers

| Domaine | Statut | Priorité | Fichier référence |
|---------|--------|----------|-------------------|
| Structure juridique (SAS) | À créer | **P0** | `01-legal/STRUCTURE-JURIDIQUE.md` |
| Garantie financière APST | À déposer | **P0** | `08-assurance-conformite/GARANTIE-FINANCIERE.md` |
| RC Pro | À souscrire | **P0** | `08-assurance-conformite/RC-PRO.md` |
| Immatriculation Atout France | Après APST + RC | **P0** | `01-legal/IMMATRICULATION-ATOUT-FRANCE.md` |
| Compte bancaire pro | Après SAS | **P0** | `14-pitch/PITCH-BANQUE.md` |
| Avocat tourisme | À trouver | P1 | `01-legal/CHECKLIST-AVOCAT.md` |
| Expert-comptable | À trouver | P1 | `13-comptabilite/GUIDE-COMPTABLE.md` |
| CGV | Template prêt (validation avocat) | P1 | `01-legal/CGV-TEMPLATE.md` |
| Contrat partenaire type | Template prêt (validation avocat) | P1 | `01-legal/CONTRAT-PARTENAIRE-TYPE.md` |
| Mentions légales | Template prêt | P1 | `01-legal/MENTIONS-LEGALES.md` |
| RGPD | Module backend OK + docs | P1 | `01-legal/RGPD-CONFORMITE.md` |
| Budget prévisionnel | Fait (3 scénarios + Excel) | P1 | `02-finance/` + `BUDGET-EVENTY.xlsx` |
| Grille tarifaire | Définie | P1 | `02-finance/GRILLE-TARIFAIRE.md` |
| Plan trésorerie | M0-M12 modélisé | P1 | `02-finance/PLAN-TRESORERIE.md` |
| Transport | Comparatif + simulateur | P2 | `03-transport/COMPARATIF-TRANSPORT.md` |
| Partenaires | Stratégie + suivi | P2 | `05-partenaires/` |
| Marketing | Plan complet + KPIs | P2 | `07-marketing-commercial/PLAN-LANCEMENT.md` |
| RH / Orga | Phases 1-3 définies | P2 | `06-rh-organisation/ORGANIGRAMME.md` |
| Hébergement cloud | Comparatif | P2 | `04-hebergement-infra/COMPARATIF-CLOUD.md` |
| Déploiement tech | Plan A/B prêt | P2 | `09-site-beta/PLAN-DEPLOIEMENT.md` |
| Process quotidien | Défini | P2 | `10-operations/PROCESS-QUOTIDIEN.md` |
| Templates emails | 19 templates (3 fichiers) | P2 | `11-templates-emails/` |
| Comptabilité | Guide TVA marge + factures | P2 | `13-comptabilite/` |
| Checklist lancement | 8 phases complètes | P2 | `12-checklist-lancement/CHECKLIST-COMPLETE.md` |
| Pitch banque | Dossier prêt | P2 | `14-pitch/PITCH-BANQUE.md` |

---

## Chemin critique (8-12 semaines)

```
Semaine 1-2 :  Créer SAS ─────────────────────► Compte bancaire pro
                    │
Semaine 1-2 :  Trouver avocat + expert-comptable
                    │
Semaine 2-4 :  Déposer dossier APST ──────────► Garantie financière
                    │
Semaine 2-3 :  Souscrire RC Pro ──────────────► Attestation
                    │
Semaine 4-6 :  Dossier Atout France ──────────► Immatriculation IM
                    │
Semaine 4-6 :  Premiers contacts partenaires ─► Contrats signés
                    │
Semaine 6-8 :  Déploiement production ────────► Site live
                    │
Semaine 8-10 : Marketing lancement ───────────► Premier voyage
                    │
Semaine 10-12: Premier voyage organisé ───────► Premiers avis clients
```

---

## Backend technique

| Métrique | Valeur |
|----------|--------|
| Modules NestJS | 29 |
| Fichiers source | 252 (.ts) |
| Fichiers tests | 121 (.spec.ts) |
| Tests totaux | 3 300+ (3 301 pass, 5 pre-existing) |
| Lignes de code | 290 477 |
| Audits backend | 7/7 complétés |
| Frontend Next.js 14 | 20+ pages |
| Prisma schema | 3 232 lignes |
| CI/CD | 4 workflows GitHub Actions |
| Module HRA | 24 endpoints, 40 tests |

---

## Budget résumé

| Scénario | Investissement | Charges/mois | Break-even estimé |
|----------|---------------|-------------|-------------------|
| Minimaliste | ~12 000€ | ~750€ | Mois 3-4 |
| Confortable | ~20 000€ | ~1 500€ | Mois 4-5 |
| Scale-ready | ~35 000€ | ~3 000€ | Mois 5-6 |

---

## Contacts prioritaires

| Contact | Pourquoi | Urgence |
|---------|----------|---------|
| Avocat tourisme | Statuts SAS + CGV + contrats | Semaine 1 |
| Expert-comptable tourisme | TVA marge, IS, facturation | Semaine 1-2 |
| APST | Garantie financière 200K€ | Semaine 2 |
| Banque pro (Qonto/Shine/BPI) | Compte + découvert + prêt | Semaine 2 |
| Assureur RC Pro | Couverture obligatoire | Semaine 2-3 |
| 3 hôtels/gîtes partenaires | Premiers catalogues | Semaine 4-6 |
| 2 autocaristes | Transport groupes | Semaine 4-6 |
| 3 prestataires activités | Programme voyages | Semaine 4-6 |

---

## Livrables interactifs

| Livrable | Description |
|----------|-------------|
| `DASHBOARD-EVENTY.html` | Dashboard interactif 7 onglets + simulateur transport + simulateur devis |
| `BUDGET-EVENTY.xlsx` | Excel 4 onglets, 72 formules, trésorerie M0-M12, simulateur transport |
| `PDG-EVENTY-COMPLET.zip` | Archive complète de tous les fichiers du projet |

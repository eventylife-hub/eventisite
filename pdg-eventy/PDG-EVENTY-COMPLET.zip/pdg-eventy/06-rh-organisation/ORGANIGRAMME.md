# Organisation & RH — Eventy

## Phase 1 : Solo-fondateur (Mois 0-6)

```
David (PDG / Fondateur)
├── Tech (développement, maintenance, déploiement)
├── Commercial (prospection partenaires, négociation)
├── Opérations (organisation voyages, relation client)
├── Admin / Finance (comptabilité, juridique)
└── Marketing (contenu, réseaux sociaux, SEO)
```

**Priorité** : Automatiser au maximum via la plateforme pour réduire le besoin en personnel.

---

## Phase 2 : Premiers recrutements (Mois 6-12)

```
David (PDG)
├── 1 Chargé(e) de voyages (freelance ou CDD)
│   ├── Relation client
│   ├── Organisation logistique
│   └── Suivi des réservations
└── 1 Commercial(e) (freelance)
    ├── Prospection partenaires
    └── Développement B2B
```

**Budget estimé** :
- Freelance chargé de voyages : 1 500€ - 2 500€/mois (temps partiel)
- Freelance commercial : 1 000€ fixe + commission sur ventes

---

## Phase 3 : Structure (Mois 12-24)

```
David (PDG / CTO)
├── Pôle Voyages
│   ├── Responsable opérations
│   ├── 1-2 Chargé(e)s de voyages
│   └── 1 Responsable partenariats
├── Pôle Tech
│   ├── 1 Développeur fullstack (senior)
│   └── 1 Développeur junior / stagiaire
├── Pôle Commercial
│   ├── 1 Commercial B2B
│   └── 1 Community manager
└── Admin
    └── Expert-comptable (externe)
```

---

## Fiches de poste clés

### Chargé(e) de voyages
- **Mission** : Organiser les voyages de A à Z, relation client, logistique
- **Compétences** : BTS Tourisme ou expérience, sens du service, organisation
- **Contrat** : Freelance puis CDI
- **Rémunération** : 1 800€ - 2 500€ net/mois

### Commercial(e) partenariats
- **Mission** : Prospecter et signer des partenaires (hébergement, transport, activités)
- **Compétences** : Expérience commerciale B2B, réseau tourisme apprécié
- **Contrat** : Freelance (fixe + variable)
- **Rémunération** : 1 200€ fixe + 5-10% commission sur marge

### Développeur fullstack
- **Mission** : Maintenance et évolution de la plateforme Eventy
- **Compétences** : NestJS, React/Next.js, PostgreSQL, Prisma
- **Contrat** : CDI ou freelance
- **Rémunération** : 3 000€ - 4 500€ net/mois (selon expérience)

---

## Process internes

### Nouveau voyage — Workflow

1. **Demande client** → formulaire en ligne ou email
2. **Qualification** → nombre de personnes, dates, budget, destination
3. **Sourcing** → sélection prestataires dans le catalogue
4. **Devis** → génération via la plateforme (module documents)
5. **Validation client** → signature électronique + acompte 30%
6. **Réservation** → confirmation prestataires
7. **Suivi** → relances solde J-30, documents voyage J-15
8. **Jour J** → contact d'urgence disponible
9. **Post-voyage** → enquête satisfaction, relance avis

### Nouveau partenaire — Workflow

1. **Identification** → recherche web, salons, bouche-à-oreille
2. **Premier contact** → email template
3. **Qualification** → grille d'évaluation
4. **Devis test** → cas concret
5. **Négociation** → contrat cadre
6. **Intégration** → ajout dans la plateforme (module HRA)
7. **Test réel** → premier voyage avec ce partenaire
8. **Évaluation** → retour client + note interne

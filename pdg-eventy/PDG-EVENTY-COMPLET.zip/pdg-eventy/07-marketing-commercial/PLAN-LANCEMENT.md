# Plan Marketing & Lancement — Eventy

## Positionnement

**Eventy** = Plateforme tech qui simplifie l'organisation de voyages de groupe.

- **Cible principale** : Groupes d'amis (25-45 ans), familles élargies, associations
- **Cible secondaire** : Entreprises (séminaires, team building), CE
- **Différenciation** : Tout-en-un digital (devis en ligne, paiement split, gestion groupe), prix transparents, réactivité

---

## Stratégie d'acquisition

### Canal 1 — SEO (gratuit, long terme)

**Mots-clés cibles** :
- "voyage de groupe" (volume élevé)
- "organiser un voyage entre amis"
- "week-end groupe pas cher"
- "séminaire entreprise France"
- "location autocar groupe"

**Actions** :
- Blog avec 2 articles/semaine (destinations, conseils, budgets)
- Pages de destination par type de voyage (weekend, semaine, séminaire)
- Pages par destination (France, Europe)
- Optimisation technique (déjà module SEO dans le backend)

**Budget** : 0€ (temps uniquement)
**Délai résultats** : 3-6 mois

### Canal 2 — Réseaux sociaux (gratuit + payant)

**Plateformes prioritaires** :
1. **Instagram** — Photos de destinations, stories des voyages, reels
2. **Facebook** — Groupes voyage, marketplace, événements
3. **TikTok** — Vidéos courtes, coulisses des voyages
4. **LinkedIn** — B2B (séminaires, CE)

**Fréquence** : 3-5 posts/semaine minimum
**Budget ads** : 200€ - 500€/mois (phase croissance)

### Canal 3 — Google Ads (payant, résultats rapides)

**Campagnes** :
- Search : "organiser voyage de groupe" → page devis
- Display : Retargeting visiteurs site
- YouTube : Vidéos destinations

**Budget** : 300€ - 1 000€/mois
**Délai résultats** : Immédiat

### Canal 4 — Partenariats & Bouche-à-oreille

**Actions** :
- Programme de parrainage : -50€ pour le parrain sur son prochain voyage
- Partenariats avec des influenceurs voyage (micro-influenceurs)
- Partenariats avec des associations, clubs sportifs, CE

**Budget** : 500€ - 1 000€/mois

---

## Plan de lancement (semaine par semaine)

### Semaine -4 : Préparation
- [ ] Finaliser le site (pages principales, UX, mobile)
- [ ] Préparer 10 articles de blog SEO
- [ ] Créer les comptes réseaux sociaux
- [ ] Préparer les visuels et templates

### Semaine -2 : Teasing
- [ ] Lancer les comptes Instagram/Facebook avec du contenu "coming soon"
- [ ] Créer une landing page "inscrivez-vous pour être informé du lancement"
- [ ] Contacter 20 micro-influenceurs voyage

### Semaine 0 : Lancement officiel
- [ ] Mettre le site en production
- [ ] Publier l'annonce de lancement sur tous les réseaux
- [ ] Envoyer un email à la liste d'inscrits
- [ ] Offre de lancement : -15% sur le premier voyage réservé
- [ ] Lancer les premières campagnes Google Ads

### Semaine +1 à +4 : Accélération
- [ ] Publier 2 articles/semaine sur le blog
- [ ] Poster quotidiennement sur les réseaux
- [ ] Relancer les leads
- [ ] Organiser le premier voyage test (gratuit ou à prix coûtant) pour obtenir du contenu et des avis

### Mois 2-3 : Optimisation
- [ ] Analyser les KPIs (taux de conversion, coût d'acquisition, panier moyen)
- [ ] A/B test pages d'atterrissage
- [ ] Optimiser les campagnes ads
- [ ] Collecter les premiers avis clients

---

## KPIs à suivre

| KPI | Objectif M1 | Objectif M3 | Objectif M6 |
|-----|------------|------------|------------|
| Visiteurs uniques/mois | 500 | 2 000 | 5 000 |
| Taux de conversion (visite → devis) | 2% | 3% | 5% |
| Devis générés/mois | 10 | 60 | 250 |
| Voyages confirmés/mois | 1 | 3 | 8 |
| CA mensuel | 6 000€ | 24 000€ | 60 000€ |
| Marge brute | 1 000€ | 3 600€ | 9 000€ |
| Coût d'acquisition client (CAC) | - | 100€ | 50€ |
| Note satisfaction (NPS) | - | 40+ | 50+ |

---

## Pricing — Offres de lancement

| Offre | Prix/pers | Inclus | Durée promo |
|-------|-----------|--------|-------------|
| Weekend découverte (2J/1N) | À partir de 149€ | Transport + hébergement + 1 activité | 3 mois |
| Weekend premium (3J/2N) | À partir de 299€ | Transport + hébergement + 2 activités + repas | 3 mois |
| Séjour semaine (7J/6N) | À partir de 599€ | Tout inclus | 3 mois |
| Séminaire entreprise | Sur devis | Personnalisé | Permanent |

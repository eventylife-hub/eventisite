# Process Quotidiens — Eventy

## Routine journalière PDG

### Matin (9h-10h) — Check
- [ ] Vérifier les emails (demandes clients, réponses partenaires)
- [ ] Consulter le dashboard (réservations, paiements, alertes)
- [ ] Vérifier l'uptime du site (UptimeRobot)
- [ ] Traiter les demandes urgentes

### Matin (10h-12h) — Production
- [ ] Traiter les demandes de devis
- [ ] Relancer les clients en attente de paiement
- [ ] Appeler les partenaires (négociation, confirmation)

### Après-midi (14h-17h) — Développement
- [ ] Prospection nouveaux partenaires
- [ ] Contenu marketing (articles, réseaux sociaux)
- [ ] Développement plateforme (features, bugs)

### Fin de journée (17h-18h) — Admin
- [ ] Mise à jour du suivi partenaires
- [ ] Mise à jour de la trésorerie
- [ ] Préparer les actions du lendemain

---

## Process clés

### 1. Nouveau devis client

| Étape | Action | Délai | Outil |
|-------|--------|-------|-------|
| 1 | Réception demande (formulaire/email) | J0 | Email / Site |
| 2 | Qualification (nb pers., dates, budget) | J0 | CRM |
| 3 | Sourcing prestataires | J0-J1 | Module HRA |
| 4 | Génération devis détaillé | J1-J2 | Module Documents |
| 5 | Envoi au client | J2 max | Email |
| 6 | Relance si pas de réponse | J+5 | Email template |
| 7 | Relance 2 | J+10 | Email |
| 8 | Clôture si pas de réponse | J+21 | CRM |

**Objectif** : Devis envoyé sous 48h maximum

### 2. Réservation confirmée

| Étape | Action | Délai |
|-------|--------|-------|
| 1 | Réception acompte 30% | J0 |
| 2 | Confirmation aux prestataires | J0-J1 |
| 3 | Envoi confirmation client + contrat | J1 |
| 4 | Demande solde | J-30 |
| 5 | Envoi documents voyage (convocation, programme) | J-15 |
| 6 | Rappel pratique (lieu RDV, horaires) | J-3 |
| 7 | Contact d'urgence le jour J | J0 |
| 8 | Enquête satisfaction post-voyage | J+3 |
| 9 | Relance avis en ligne | J+7 |
| 10 | Proposition voyage suivant | J+30 |

### 3. Gestion des réclamations

| Sévérité | Exemple | Délai réponse | Action |
|----------|---------|---------------|--------|
| Faible | Chambre pas conforme | 48h | Excuses + geste commercial |
| Moyenne | Activité annulée | 24h | Remplacement ou remboursement partiel |
| Haute | Problème sécurité, rapatriement | Immédiat | Intervention d'urgence + assurance |
| Critique | Accident, blessure | Immédiat | Urgences + assurance + communication crise |

---

## KPIs hebdomadaires

| KPI | Objectif |
|-----|----------|
| Nombre de devis envoyés | 5+/semaine |
| Taux de conversion devis → résa | > 20% |
| Délai moyen envoi devis | < 48h |
| Nombre de nouveaux partenaires contactés | 5+/semaine |
| Réponse client < 24h | 100% |
| Note satisfaction | > 4/5 |
| Trésorerie disponible | > 3 mois de charges |

---

## Outils de travail

| Usage | Outil | Coût |
|-------|-------|------|
| Email pro | Google Workspace | 7€/mois |
| Banque | Qonto / Shine | 9-30€/mois |
| Comptabilité | Pennylane / Tiime | 30-80€/mois |
| CRM | HubSpot Free ou Notion | 0€ |
| Gestion projet | Notion / Trello | 0€ |
| Communication | Slack (free) | 0€ |
| Visio | Google Meet / Zoom Free | 0€ |
| Design / Marketing | Canva Pro | 12€/mois |
| Réseaux sociaux | Buffer Free | 0€ |

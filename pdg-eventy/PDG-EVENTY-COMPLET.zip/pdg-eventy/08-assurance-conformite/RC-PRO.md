# Assurance RC Pro — Eventy

## Obligation légale

L'assurance Responsabilité Civile Professionnelle est obligatoire pour toute agence de voyages. Elle couvre les dommages (matériels, corporels, immatériels) causés à des tiers dans le cadre de l'activité.

## Couverture recommandée

- **Montant de garantie** : 300 000€ minimum recommandé
- **Franchise** : Négociable (500€ - 1 500€ typique)

## Tarification

| Type d'agence | Prix annuel estimé |
|--------------|-------------------|
| Agence en création (faible CA) | 780€ - 1 200€ |
| Agence active (CA < 500k€) | 1 200€ - 2 000€ |
| Agence établie (CA > 500k€) | 2 000€ - 5 000€ |

## Risques couverts

- Annulation de prestation par un fournisseur
- Défaut de conseil au client
- Erreur dans l'organisation du voyage
- Accident pendant le voyage (responsabilité organisateur)
- Dommages aux bagages
- Retard important ayant causé un préjudice

## Assureurs spécialisés tourisme

| Assureur | Spécificité | Contact |
|----------|-------------|---------|
| Orus | Devis en ligne en 3 min | orus.eu |
| Hiscox | Spécialisé agences digitales | hiscox.fr |
| Assurup | Comparateur pro | assurup.com |
| Coover | Comparateur, devis gratuit | coover.fr |
| MMA/AXA/Allianz | Assureurs généralistes | Via courtier |

## Procédure

1. **Demander 3-5 devis** via les comparateurs ci-dessus
2. **Comparer** : prix, franchises, plafonds, exclusions
3. **Souscrire** le contrat le plus adapté
4. **Obtenir l'attestation** : nécessaire pour l'immatriculation Atout France
5. **Renouveler** annuellement et envoyer l'attestation à Atout France

## Checklist

- [ ] Demander devis sur Orus, Coover, Assurup
- [ ] Comparer les offres (prix, garanties, franchise)
- [ ] Souscrire le contrat
- [ ] Obtenir l'attestation RC Pro
- [ ] Transmettre à Atout France
- [ ] Afficher le numéro de police sur le site et les documents

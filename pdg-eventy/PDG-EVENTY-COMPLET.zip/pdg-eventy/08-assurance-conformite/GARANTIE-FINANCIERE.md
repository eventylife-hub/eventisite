# Garantie Financière — Eventy

## Obligation légale

Toute agence de voyages immatriculée auprès d'Atout France doit disposer d'une garantie financière. Cette garantie protège les clients en cas de défaillance de l'agence (remboursement des acomptes et rapatriement).

## Montant minimum

- **200 000€ minimum** (seuil légal)
- Doit couvrir la totalité des fonds déposés par les clients (depuis le 1er octobre 2015)

## Organismes de garantie

### Option 1 : APST (recommandé)

L'Association Professionnelle de Solidarité du Tourisme est le premier garant financier du secteur (2/3 des agences).

| Poste | Montant |
|-------|---------|
| Cotisation annuelle (agence) | ~2 100€ |
| Part variable (distributeur, 0,7%) | ~900€ |
| Contre-garantie | Selon dossier (caution bancaire possible) |

**Avantages** :
- Reconnaissance du secteur
- Accompagnement des adhérents
- Réseau et crédibilité

**Contact** : https://apst.travel

### Option 2 : Assureur privé

Certains assureurs (Groupama, Atradius) proposent des garanties financières.

| Poste | Montant estimé |
|-------|---------------|
| Prime annuelle | 1 500€ - 5 000€ |
| Contre-garantie | Variable |

**Avantages** : Peut être moins cher que l'APST pour les petites agences
**Inconvénients** : Moins de reconnaissance sectorielle

### Option 3 : Établissement de crédit

Une banque peut émettre une caution pour la garantie financière.

**Avantages** : Simple si bonne relation bancaire
**Inconvénients** : Immobilise de la trésorerie

---

## Contre-garantie

L'APST (ou l'assureur) peut demander une contre-garantie :
- Caution bancaire
- Nantissement de compte
- Caution personnelle du dirigeant

Pour une agence en création avec peu de CA, la contre-garantie demandée est généralement minimale.

---

## Procédure d'adhésion APST

1. Remplir le dossier de candidature
2. Fournir le Kbis, les statuts, le business plan
3. Passage en commission d'adhésion
4. Paiement de la cotisation
5. Délivrance de l'attestation de garantie

**Délai** : 2 à 4 semaines

---

## Checklist

- [ ] Choisir l'organisme de garantie (APST recommandé)
- [ ] Préparer le dossier de candidature
- [ ] Constituer la contre-garantie si nécessaire
- [ ] Soumettre le dossier
- [ ] Obtenir l'attestation de garantie financière
- [ ] Transmettre l'attestation à Atout France (pour l'immatriculation)

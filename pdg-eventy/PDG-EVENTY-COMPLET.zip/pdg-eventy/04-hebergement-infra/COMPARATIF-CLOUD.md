# Comparatif Hébergement Cloud — Eventy

## Stack technique actuelle
- **Backend** : NestJS (Node.js) + Prisma + PostgreSQL
- **Frontend** : À définir (probablement Next.js)
- **Paiement** : Stripe
- **Stockage fichiers** : S3 compatible

---

## Comparatif fournisseurs

### Option A : Scaleway (recommandé pour le lancement)

| Service | Offre | Prix/mois | Notes |
|---------|-------|-----------|-------|
| Instance DEV1-S | 2 vCPU, 2 Go RAM | 4,99€ | Backend NestJS |
| Instance DEV1-M | 3 vCPU, 4 Go RAM | 9,99€ | Si charge augmente |
| PostgreSQL managé | Essential, 1 noeud | 13,44€ | Database managée |
| Object Storage | S3 compatible | 0,01€/Go | Uploads, documents |
| **TOTAL démarrage** | | **~20-30€/mois** | |

**Avantages** : Cloud-native, facturation à la seconde, datacenters France (Paris), API moderne, RGPD compliant, bonne DX

### Option B : OVHcloud

| Service | Offre | Prix/mois | Notes |
|---------|-------|-----------|-------|
| VPS Starter | 1 vCPU, 2 Go RAM | 3,50€ | Entrée de gamme |
| VPS Value | 2 vCPU, 4 Go RAM | 5,75€ | Recommandé |
| CloudDB PostgreSQL | Starter | ~15€ | Database managée |
| Object Storage | S3 compatible | 0,01€/Go | |
| **TOTAL démarrage** | | **~20-25€/mois** | |

**Avantages** : Prix très compétitifs, datacenters France, souverain
**Attention** : Hausses de prix annoncées 2026 (jusqu'à +45%), DX moins moderne

### Option C : Vercel + Neon/Supabase (JAMstack)

| Service | Offre | Prix/mois | Notes |
|---------|-------|-----------|-------|
| Vercel Pro | Frontend Next.js | 20€ | Déploiement automatique |
| Neon PostgreSQL | Free tier puis Pro | 0€ - 19€ | Serverless PostgreSQL |
| Railway | Backend NestJS | 5€ - 20€ | Alternative pour le backend |
| **TOTAL démarrage** | | **~25-60€/mois** | |

**Avantages** : DX excellente, déploiement push-to-deploy, scaling automatique
**Inconvénients** : Données hors France (USA), RGPD potentiellement problématique

### Option D : Hetzner (économique)

| Service | Offre | Prix/mois | Notes |
|---------|-------|-----------|-------|
| VPS CX22 | 2 vCPU, 4 Go RAM | 5,19€ | Excellent rapport qualité/prix |
| PostgreSQL managé | Pas disponible | Auto-géré | À installer soi-même |
| **TOTAL démarrage** | | **~5-10€/mois** | |

**Avantages** : Moins cher, datacenters Allemagne (RGPD OK)
**Inconvénients** : Moins de services managés, +37% hausse annoncée 2026

---

## Recommandation

### Phase 1 (lancement — budget serré)
**Scaleway DEV1-S + PostgreSQL managé** = ~25€/mois
- Hébergé en France (RGPD ++)
- Services managés (pas de DevOps)
- Scaling facile si besoin

### Phase 2 (croissance)
**Scaleway PRO2-S + PostgreSQL HA** = ~80-150€/mois
- Plus de ressources
- Base de données haute disponibilité
- CDN + load balancer

### Phase 3 (scale)
**Kubernetes managé (Scaleway Kapsule)** = 200-500€/mois
- Orchestration automatique
- Auto-scaling
- Multi-instances

---

## Services complémentaires

| Service | Fournisseur | Prix | Notes |
|---------|-------------|------|-------|
| Domaine eventy.fr | OVH / Gandi | 10-15€/an | |
| Email pro | Google Workspace | 7€/user/mois | |
| DNS + CDN | Cloudflare Free | 0€ | Performance + sécurité |
| SSL | Let's Encrypt | 0€ | Via Caddy ou reverse proxy |
| Monitoring | UptimeRobot Free | 0€ | Alertes uptime |
| Logs | Grafana Cloud Free | 0€ | 50 Go logs/mois |
| Erreurs | Sentry Free | 0€ | 5k events/mois |
| CI/CD | GitHub Actions | 0€ | 2000 min/mois free |

---

## Checklist infra

- [ ] Créer compte Scaleway
- [ ] Provisionner instance DEV1-S (ou DEV1-M)
- [ ] Créer instance PostgreSQL managée
- [ ] Configurer Object Storage S3
- [ ] Configurer le domaine eventy.fr (DNS Cloudflare)
- [ ] Mettre en place CI/CD (GitHub Actions)
- [ ] Configurer monitoring (UptimeRobot + Sentry)
- [ ] Configurer les backups automatiques de la DB
- [ ] Mettre en place les certificats SSL
- [ ] Configurer les emails transactionnels (Brevo ou SendGrid)

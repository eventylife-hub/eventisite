# Plan de Déploiement Technique — Eventy

> **Objectif** : Passer du développement local à la production

---

## Architecture cible

```
                    ┌─────────────┐
                    │   Cloudflare │ (DNS + CDN + WAF)
                    └──────┬──────┘
                           │
              ┌────────────┼────────────┐
              ▼                         ▼
    ┌──────────────┐          ┌──────────────┐
    │   Vercel      │          │   Railway /   │
    │   (Frontend)  │          │   Render      │
    │   Next.js 14  │          │   (Backend)   │
    │               │◄────────►│   NestJS 10   │
    └──────────────┘   API     └──────┬───────┘
                                      │
                           ┌──────────┼──────────┐
                           ▼                     ▼
                 ┌──────────────┐      ┌──────────────┐
                 │  PostgreSQL   │      │    Redis      │
                 │  (Supabase    │      │  (Upstash)    │
                 │   ou Neon)    │      │               │
                 └──────────────┘      └──────────────┘
```

---

## Option A — Budget minimal (~20€/mois)

| Service | Fournisseur | Plan | Coût/mois |
|---------|------------|------|-----------|
| Frontend | Vercel | Hobby → Pro | 0€ → 20€ |
| Backend | Railway | Starter | 5€ |
| BDD PostgreSQL | Neon / Supabase | Free tier | 0€ |
| Redis | Upstash | Free tier | 0€ |
| DNS + CDN | Cloudflare | Free | 0€ |
| Email transac. | Brevo | Free (300/jour) | 0€ |
| Stockage fichiers | Cloudflare R2 | Free (10 Go) | 0€ |
| Monitoring | Sentry | Developer | 0€ |
| **TOTAL** | | | **~5-25€/mois** |

## Option B — Production sérieuse (~80€/mois)

| Service | Fournisseur | Plan | Coût/mois |
|---------|------------|------|-----------|
| Frontend | Vercel | Pro | 20€ |
| Backend | Railway | Pro (2 vCPU, 2 Go) | 20€ |
| BDD PostgreSQL | Supabase Pro | 25 Go | 25€ |
| Redis | Upstash Pro | | 10€ |
| DNS + CDN + WAF | Cloudflare | Pro | 0€ (suffisant) |
| Email transac. | Brevo Starter | 20K/mois | 9€ |
| Monitoring | Sentry Team | | 0€ (free) |
| **TOTAL** | | | **~85€/mois** |

---

## Étapes de déploiement

### Phase 1 — Infrastructure (Jour 1-2)

**1.1 Domaine et DNS**
- [ ] Acheter eventy.life (si pas fait) via Cloudflare Registrar
- [ ] Configurer DNS Cloudflare : A/CNAME vers Vercel + Backend
- [ ] Activer HTTPS automatique (Cloudflare + providers)
- [ ] Configurer sous-domaines : api.eventy.life, app.eventy.life

**1.2 Base de données**
- [ ] Créer instance PostgreSQL (Supabase ou Neon)
- [ ] Exécuter `npx prisma migrate deploy` en production
- [ ] Exécuter `npx prisma db seed` (données de base)
- [ ] Configurer backups automatiques (quotidiens)
- [ ] Tester connexion SSL depuis le backend

**1.3 Redis**
- [ ] Créer instance Upstash Redis
- [ ] Configurer URL dans les variables d'environnement
- [ ] Tester rate limiting et cache

### Phase 2 — Backend (Jour 2-3)

**2.1 Variables d'environnement (CRITIQUES)**
```env
# Base de données
DATABASE_URL=postgresql://user:pass@host:5432/eventy?sslmode=require

# JWT
JWT_SECRET=[générer 64 chars aléatoires]
JWT_EXPIRATION=15m
JWT_REFRESH_EXPIRATION=7d

# Stripe
STRIPE_SECRET_KEY=sk_live_[...]
STRIPE_WEBHOOK_SECRET=whsec_[...]

# Email
SMTP_HOST=smtp-relay.brevo.com
SMTP_PORT=587
SMTP_USER=[clé API]
SMTP_PASS=[clé API]
EMAIL_FROM=contact@eventy.life

# Redis
REDIS_URL=rediss://default:[pass]@[host]:6379

# Divers
NODE_ENV=production
CORS_ORIGINS=https://eventy.life,https://www.eventy.life
UPLOAD_MAX_SIZE=10485760
```

**2.2 Déploiement backend**
- [ ] Push code sur branche `main` (GitHub)
- [ ] Connecter Railway/Render au repo GitHub
- [ ] Configurer auto-deploy sur push `main`
- [ ] Vérifier healthcheck : `GET /health`
- [ ] Configurer Stripe webhook production : `POST api.eventy.life/webhooks/stripe`

### Phase 3 — Frontend (Jour 3-4)

**3.1 Déploiement Vercel**
- [ ] Connecter le repo GitHub à Vercel
- [ ] Configurer les variables d'env (NEXT_PUBLIC_API_URL, etc.)
- [ ] Lier le domaine eventy.life
- [ ] Vérifier build + SSR OK
- [ ] Tester navigation complète

### Phase 4 — Sécurité (Jour 4-5)

- [ ] Activer Cloudflare WAF (règles basiques)
- [ ] Vérifier rate limiting backend (déjà codé)
- [ ] Tester auth flow complet (inscription → login → refresh)
- [ ] Vérifier CORS (seuls les domaines autorisés)
- [ ] Scanner sécurité : `npm audit` + headers HTTP (securityheaders.com)
- [ ] Configurer CSP (Content Security Policy)
- [ ] Vérifier que les données Stripe ne sont jamais loguées

### Phase 5 — Monitoring (Jour 5)

- [ ] Configurer Sentry (frontend + backend)
- [ ] Configurer alertes email pour erreurs 500+
- [ ] Mettre en place uptime monitoring (UptimeRobot, gratuit)
- [ ] Configurer les cron jobs backend (Railway cron ou pg_cron)
- [ ] Dashboard Vercel Analytics activé

### Phase 6 — Test final (Jour 5-7)

- [ ] Parcours utilisateur complet : inscription → recherche → devis → réservation → paiement
- [ ] Parcours PRO : inscription → gestion prestations → réponse bloc hôtel
- [ ] Parcours ADMIN : dashboard → gestion voyages → validation
- [ ] Test mobile (responsive)
- [ ] Test performance : Lighthouse > 80 sur toutes les pages
- [ ] Test email transactionnels (confirmation, facture)
- [ ] Test paiement Stripe en mode live (petit montant)

---

## Checklist Go/No-Go

| Critère | Requis | Statut |
|---------|--------|--------|
| Immatriculation Atout France | Obligatoire | [ ] |
| RC Pro active | Obligatoire | [ ] |
| Garantie financière APST | Obligatoire | [ ] |
| Mentions légales publiées | Obligatoire | [ ] |
| CGV publiées | Obligatoire | [ ] |
| RGPD (politique confidentialité) | Obligatoire | [ ] |
| Bandeau cookies fonctionnel | Obligatoire | [ ] |
| Paiement Stripe fonctionnel | Obligatoire | [ ] |
| Emails transactionnels OK | Obligatoire | [ ] |
| SSL/HTTPS partout | Obligatoire | [ ] |
| Backup BDD automatique | Critique | [ ] |
| Monitoring erreurs | Important | [ ] |
| Mobile responsive | Important | [ ] |

---

## Post-déploiement

### Semaine 1
- Surveiller les logs et erreurs Sentry quotidiennement
- Vérifier les paiements Stripe dans le dashboard
- Répondre aux premiers contacts en moins de 2h

### Semaine 2-4
- Analyser le trafic (Vercel Analytics + Cloudflare)
- Optimiser les pages lentes (> 3s)
- Corriger les bugs remontés

### Mensuel
- Mise à jour des dépendances (`npm audit fix`)
- Revue des coûts infrastructure
- Backup test de restauration

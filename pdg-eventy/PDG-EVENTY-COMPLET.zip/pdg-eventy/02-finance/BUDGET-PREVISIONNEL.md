# Budget Prévisionnel — Eventy

## Budget enveloppe : 15 000€ - 50 000€

---

## 1. Coûts de création (one-shot)

| Poste | Min | Max | Priorité |
|-------|-----|-----|----------|
| Rédaction statuts SAS (avocat) | 1 500€ | 3 000€ | P0 |
| Annonce légale + greffe | 200€ | 300€ | P0 |
| Capital social (dépôt) | 1 000€ | 5 000€ | P0 |
| Pack juridique (CGV/CGU/mentions) | 2 500€ | 5 000€ | P0 |
| Comptable (mise en place) | 500€ | 1 000€ | P0 |
| **Sous-total création** | **5 700€** | **14 300€** | |

## 2. Coûts obligatoires agence (one-shot / annuels)

| Poste | Min | Max | Fréquence |
|-------|-----|-----|-----------|
| Garantie financière (APST) | 2 100€ | 3 500€ | Annuel (cotisation) |
| Contre-garantie bancaire | 0€ | 5 000€ | Selon dossier |
| RC Pro assurance | 780€ | 2 000€ | Annuel |
| Immatriculation Atout France | 0€ | 0€ | Gratuit depuis 2019 |
| **Sous-total agence** | **2 880€** | **10 500€** | |

## 3. Coûts techniques (mensuels)

| Poste | Min/mois | Max/mois | Annuel min |
|-------|----------|----------|------------|
| Hébergement cloud (VPS/Cloud) | 30€ | 150€ | 360€ |
| Base de données managée | 20€ | 80€ | 240€ |
| Domaine + SSL | 2€ | 5€ | 24€ |
| Email pro (Google Workspace) | 7€ | 14€ | 84€ |
| Stripe (frais transaction) | Variable | 1,4% + 0,25€ | Variable |
| CDN / Vercel Pro | 0€ | 20€ | 240€ |
| Monitoring (Sentry, etc.) | 0€ | 26€ | 312€ |
| **Sous-total tech/mois** | **~60€** | **~300€** | **~1 260€** |

## 4. Coûts récurrents business (mensuels)

| Poste | Min/mois | Max/mois |
|-------|----------|----------|
| Expert-comptable | 100€ | 300€ |
| Logiciel comptabilité (Pennylane, etc.) | 30€ | 80€ |
| Banque pro (Qonto, Shine) | 9€ | 30€ |
| Assurance multirisque | 50€ | 150€ |
| Marketing digital (SEO, ads) | 0€ | 500€ |
| **Sous-total business/mois** | **~190€** | **~1 060€** |

---

## Scénarios budget total Année 1

### Scénario A — Minimaliste (15 000€)

| Catégorie | Montant |
|-----------|---------|
| Création société | 5 700€ |
| Obligations agence | 2 880€ |
| Tech (12 mois) | 720€ |
| Business (12 mois) | 2 280€ |
| Trésorerie de sécurité | 3 420€ |
| **TOTAL** | **15 000€** |

### Scénario B — Confortable (30 000€)

| Catégorie | Montant |
|-----------|---------|
| Création société (avocat) | 8 000€ |
| Obligations agence | 5 000€ |
| Tech (12 mois) | 2 400€ |
| Business (12 mois) | 6 000€ |
| Marketing lancement | 3 000€ |
| Trésorerie de sécurité | 5 600€ |
| **TOTAL** | **30 000€** |

### Scénario C — Scale-ready (50 000€)

| Catégorie | Montant |
|-----------|---------|
| Création société (avocat spécialisé) | 10 000€ |
| Obligations agence | 7 000€ |
| Tech (12 mois premium) | 3 600€ |
| Business (12 mois) | 8 000€ |
| Marketing lancement + SEA | 8 000€ |
| Premiers salaires/freelances | 8 000€ |
| Trésorerie de sécurité | 5 400€ |
| **TOTAL** | **50 000€** |

---

## Seuil de rentabilité estimé

Hypothèses :
- Commission moyenne : 12-15% sur le prix du voyage
- Panier moyen voyage de groupe : 800€/personne
- Groupe moyen : 15 personnes
- CA moyen par voyage : 12 000€
- Marge par voyage : 1 440€ - 1 800€
- Coûts fixes mensuels : ~1 000€ - 2 000€

**Break-even : ~1-2 voyages/mois** (hors rémunération dirigeant)

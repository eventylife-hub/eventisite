# Plan de Trésorerie Mois par Mois — Eventy

## Mois 0 : Pré-création

| Entrée | Montant | Sortie | Montant |
|--------|---------|--------|---------|
| Apport personnel | 30 000€ | | |
| | | Dépôt capital | -5 000€ |
| | | Avocat (statuts) | -2 000€ |
| | | Annonce légale + greffe | -250€ |
| **Solde fin de mois** | | | **22 750€** |

## Mois 1 : Création + obligations

| Entrée | Montant | Sortie | Montant |
|--------|---------|--------|---------|
| | | Garantie financière APST | -2 500€ |
| | | RC Pro (annuel) | -1 000€ |
| | | Pack juridique CGV/CGU | -3 000€ |
| | | Comptable (mise en place) | -500€ |
| | | Hébergement + tech | -100€ |
| | | Banque pro | -15€ |
| **Solde fin de mois** | | | **15 635€** |

## Mois 2 : Lancement opérationnel

| Entrée | Montant | Sortie | Montant |
|--------|---------|--------|---------|
| | | Comptable mensuel | -200€ |
| | | Tech (cloud + outils) | -150€ |
| | | Marketing (SEO + contenu) | -500€ |
| | | Banque + logiciels | -50€ |
| | | Prospection partenaires | -200€ |
| **Solde fin de mois** | | | **14 535€** |

## Mois 3-6 : Montée en charge

Coûts fixes mensuels estimés : ~1 100€/mois

| Mois | CA estimé | Marge | Coûts fixes | Solde cumulé |
|------|-----------|-------|-------------|--------------|
| M3 | 0€ | 0€ | -1 100€ | 13 435€ |
| M4 | 6 000€ | 900€ | -1 100€ | 13 235€ |
| M5 | 12 000€ | 1 800€ | -1 200€ | 13 835€ |
| M6 | 18 000€ | 2 700€ | -1 200€ | 15 335€ |

## Mois 7-12 : Stabilisation

| Mois | CA estimé | Marge | Coûts fixes | Solde cumulé |
|------|-----------|-------|-------------|--------------|
| M7 | 24 000€ | 3 600€ | -1 500€ | 17 435€ |
| M8 | 24 000€ | 3 600€ | -1 500€ | 19 535€ |
| M9 | 30 000€ | 4 500€ | -1 500€ | 22 535€ |
| M10 | 30 000€ | 4 500€ | -1 500€ | 25 535€ |
| M11 | 36 000€ | 5 400€ | -2 000€ | 28 935€ |
| M12 | 36 000€ | 5 400€ | -2 000€ | 32 335€ |

## Indicateurs clés

- **Runway** (sans aucun CA) : ~14 mois avec 15 000€ de trésorerie initiale
- **Point mort mensuel** : ~1 500€ de marge brute = 1 voyage de 10 personnes
- **Objectif M12** : 3 voyages/mois, trésorerie positive

## Règles de gestion

1. **Trésorerie minimum** : Toujours garder 3 mois de charges fixes en réserve
2. **Encaissement client** : Acompte 30% immédiat, solde J-30
3. **Paiement fournisseurs** : Négocier J+30 minimum
4. **BFR** : Surveiller l'écart entre encaissements et décaissements (les clients paient avant, les fournisseurs après = BFR favorable)

# Grille Tarifaire — Eventy

## Modèle de revenus

Eventy combine deux sources de revenus :
1. **Commission sur les voyages organisés** (revenu principal)
2. **Frais de service plateforme** (revenu SaaS futur)

---

## 1. Commission voyages

### Barème standard

| Type de prestation | Commission Eventy | Notes |
|--------------------|-------------------|-------|
| Hébergement | 10-15% | Négociable selon volume |
| Transport autocar | 8-12% | Marge réduite, gros volume |
| Vols | 5-8% | Marges faibles, volume élevé |
| Activités | 15-25% | Meilleure marge |
| Restauration | 10-15% | Dépend des contrats |
| Assurance voyage | 20-30% | Revente avec commission élevée |

### Frais de dossier

| Prestation | Montant |
|-----------|---------|
| Frais de dossier (par réservation) | 25€ - 50€ |
| Frais de modification | 30€ - 50€ |
| Frais annulation (selon barème CGV) | 30% - 100% |

### Exemples de pricing

**Voyage groupe 15 personnes — Weekend 3J/2N en France**
| Poste | Coût/pers | Total | Commission | Marge |
|-------|-----------|-------|------------|-------|
| Hébergement (2 nuits) | 120€ | 1 800€ | 12% | 216€ |
| Transport autocar | 50€ | 750€ | 10% | 75€ |
| Activités (2) | 80€ | 1 200€ | 20% | 240€ |
| Restauration (4 repas) | 100€ | 1 500€ | 12% | 180€ |
| Assurance | 15€ | 225€ | 25% | 56€ |
| Frais de dossier | 35€ | 525€ | 100% | 525€ |
| **TOTAL** | **400€** | **6 000€** | | **1 292€** |

**Marge brute : 21,5%**

---

## 2. Frais plateforme (SaaS — Phase 2)

| Service | Prix/mois | Cible |
|---------|-----------|-------|
| Compte Pro gratuit | 0€ | Prestataires |
| Compte Pro Premium | 29€ | Visibilité + outils |
| Compte Agence | 99€ | Sous-agences |
| Commission plateforme | 3-5% | Sur réservations tiers |

---

## 3. Politique de prix

### Principes
- Prix affichés TTC (obligation légale)
- Pas de frais cachés — transparence totale
- Prix par personne, base chambre double
- Suppléments clairement indiqués (single, vue mer, etc.)
- Révision de prix limitée aux cas prévus par la loi (carburant, taxes, devises)

### Acompte et paiement
- Réservation : 30% d'acompte
- Solde : J-30 avant départ
- Split payment disponible (module checkout du backend)
- Paiement CB via Stripe (frais : 1,4% + 0,25€ par transaction)

# Guide Comptable — Agence de Voyages Eventy

> **Important** : À valider avec un expert-comptable spécialisé tourisme

---

## 1. Régime fiscal applicable

### TVA sur la marge (Article 266-1-b CGI)

Les agences de voyages sont soumises au **régime de TVA sur la marge** :

| Élément | Règle |
|---------|-------|
| Base imposable | CA TTC − Coûts TTC (= marge brute) |
| Taux TVA | 20% (sur la marge uniquement) |
| Formule | TVA = Marge TTC × 20/120 |
| Facture client | Prix TTC global, **pas de TVA détaillée** |
| Droit à déduction | **Pas de déduction** de TVA sur les achats voyage |

### Exemple concret

```
Voyage vendu au client :          6 000€ TTC
Coûts prestataires :             -4 800€ TTC
= Marge brute :                   1 200€ TTC
TVA sur la marge : 1 200 × 20/120 = 200€
Marge nette HT :                  1 000€
```

### Exceptions (TVA classique applicable)
- Prestations réalisées en propre (si Eventy gère directement un hébergement)
- Ventes à d'autres professionnels du tourisme (B2B entre agences)
- Prestations de services pures (conseil, SaaS)

---

## 2. Plan comptable simplifié

### Comptes principaux

| N° Compte | Libellé | Usage |
|-----------|---------|-------|
| **706** | Prestations de services | CA voyages (commissions) |
| **706100** | Commissions hébergement | Détail par type |
| **706200** | Commissions transport | |
| **706300** | Commissions activités | |
| **706400** | Frais de dossier | |
| **706500** | Revenus plateforme SaaS | Phase 2 |
| **607** | Achats de prestations | Coûts prestataires |
| **607100** | Achats hébergement | |
| **607200** | Achats transport | |
| **607300** | Achats activités/restauration | |
| **616** | Primes d'assurance | RC Pro + garantie APST |
| **617** | Études et recherches | Frais Atout France |
| **623** | Publicité | Marketing, Google Ads |
| **626** | Frais postaux et télécom | Brevo, téléphone |
| **628** | Divers services | Hébergement cloud, Stripe fees |
| **641** | Rémunération du personnel | Salaires si employés |
| **455** | Compte courant associé | Apports David |

### Journaux comptables

| Journal | Code | Contenu |
|---------|------|---------|
| Ventes | VE | Factures clients |
| Achats | HA | Factures prestataires |
| Banque | BQ | Mouvements bancaires |
| Opérations diverses | OD | TVA, salaires, provisions |

---

## 3. Facturation

### Facture client (TVA sur la marge)

**Mentions obligatoires** :
- Numéro de facture (séquentiel : EV-2026-001)
- Date d'émission
- Identité complète Eventy (raison sociale, SIRET, immatriculation Atout France)
- Identité du client
- Description du voyage
- **Prix TTC global** (ne PAS détailler la TVA)
- Mention : « TVA sur la marge — Article 266-1-b du CGI »
- Conditions de paiement

**Numérotation recommandée** : EV-AAAA-XXXX (ex: EV-2026-0001)

### Facture prestataire (achat)

- Conserver toutes les factures reçues (obligation 10 ans)
- Les montants TTC sont la base de calcul de la marge
- Pas de déduction de TVA (régime marge)

---

## 4. Obligations déclaratives

### Déclarations périodiques

| Déclaration | Fréquence | Échéance |
|------------|-----------|----------|
| TVA (CA3) | Mensuelle ou trimestrielle | 15-24 du mois suivant |
| IS (acomptes) | Trimestrielle | 15 mars, 15 juin, 15 sept, 15 déc |
| IS (solde) | Annuelle | 15 mai N+1 |
| Liasse fiscale | Annuelle | 2e jour ouvré suivant le 1er mai |
| DAS2 | Annuelle (si honoraires > 1 200€) | 1er mai |
| Déclaration TVA marge | Mensuelle (ligne spécifique CA3) | Avec la TVA |

### Taux IS applicable (SAS)

| Tranche de bénéfice | Taux IS |
|---------------------|---------|
| 0 — 42 500€ | 15% (PME) |
| Au-delà de 42 500€ | 25% |

Condition PME : CA < 10M€, capital détenu à 75%+ par des personnes physiques.

---

## 5. Gestion de trésorerie — Spécificités agence

### Flux financiers types

```
Client paie 6 000€ TTC (acompte 30% + solde)
    │
    ├── → Paiement prestataire hôtel : 1 800€
    ├── → Paiement prestataire transport : 750€
    ├── → Paiement prestataire activités : 1 200€
    ├── → Paiement prestataire restauration : 1 050€
    ├── → TVA sur la marge à reverser : 200€
    └── → Marge nette Eventy : 1 000€
```

### Règles de trésorerie
- Encaisser l'acompte client (30%) AVANT de confirmer les prestataires
- Payer les prestataires APRÈS encaissement du solde client (J-30)
- Maintenir 2 mois de charges fixes en trésorerie minimum
- Séparer compte opérationnel / compte de réserve

### Frais Stripe à prévoir

| Type | Coût |
|------|------|
| Paiement CB | 1,4% + 0,25€ par transaction |
| Paiement SEPA | 0,35€ par transaction |
| Remboursement | Frais initiaux non restitués |
| Litige/chargeback | 15€ par litige |

---

## 6. Logiciel comptable recommandé

| Logiciel | Prix/mois | Points forts | Adapté agence voyage |
|----------|-----------|-------------|---------------------|
| Pennylane | 49€ | Moderne, API, collaboration expert-comptable | Oui |
| Indy | 22€ | Simple, auto-catégorisation | Basique |
| Tiime | 0€ (avec EC partenaire) | Gratuit, synchronisation bancaire | Oui |
| QuickBooks | 15€ | International | Moyen |

**Recommandation** : Pennylane ou Tiime avec un expert-comptable partenaire spécialisé tourisme.

---

## 7. Documents à conserver

| Document | Durée légale |
|----------|-------------|
| Factures émises et reçues | 10 ans |
| Relevés bancaires | 10 ans |
| Déclarations fiscales | 6 ans |
| Contrats clients et prestataires | 5 ans après fin |
| Bulletins de paie | Durée illimitée |
| Registre des traitements RGPD | Tant que l'activité dure |

# Modèle de Facture — Eventy

> **Usage** : Template à implémenter dans le module documents du backend

---

## Facture client (voyage)

```
╔══════════════════════════════════════════════════════════════╗
║                         EVENTY                              ║
║  SAS au capital de [X]€                                     ║
║  [Adresse siège social]                                     ║
║  SIRET : [numéro] — RCS [Ville] B [numéro]                ║
║  TVA : FR[XX][numéro]                                       ║
║  Immatriculation Atout France : IM[XXX]XXXXX                ║
║  Garantie : APST — RC Pro : [Assureur] n°[police]          ║
╠══════════════════════════════════════════════════════════════╣
║                                                              ║
║  FACTURE N° EV-2026-XXXX          Date : JJ/MM/AAAA        ║
║                                                              ║
║  Client :                                                    ║
║  [Nom / Raison sociale]                                      ║
║  [Adresse]                                                   ║
║  [Email]                                                     ║
║                                                              ║
╠══════════════════════════════════════════════════════════════╣
║  VOYAGE : [Destination] — [Dates] — [Nb participants] pers ║
╠══════════════════════════════════════════════════════════════╣
║                                                              ║
║  Désignation                    Qté    P.U. TTC    Total    ║
║  ─────────────────────────────────────────────────────────── ║
║  Hébergement [Hôtel]            2 nuits  60,00€    120,00€  ║
║  Transport autocar A/R          1        50,00€     50,00€  ║
║  Activité : [Nom activité 1]   1        40,00€     40,00€  ║
║  Activité : [Nom activité 2]   1        40,00€     40,00€  ║
║  Restauration (4 repas)         4        25,00€    100,00€  ║
║  Assurance voyage               1        15,00€     15,00€  ║
║  Frais de dossier               1        35,00€     35,00€  ║
║  ─────────────────────────────────────────────────────────── ║
║                                                              ║
║                          TOTAL TTC :         400,00€         ║
║                                                              ║
║  TVA sur la marge — Art. 266-1-b du CGI                     ║
║  (TVA non détaillée conformément au régime                  ║
║   de TVA sur la marge des agences de voyages)               ║
║                                                              ║
╠══════════════════════════════════════════════════════════════╣
║  PAIEMENT                                                    ║
║  ─────────────────────────────────────────────────────────── ║
║  Acompte versé (30%) :              120,00€  le JJ/MM/AAAA ║
║  Solde à régler :                   280,00€  avant J-30    ║
║  ─────────────────────────────────────────────────────────── ║
║  Mode de paiement : Carte bancaire via Stripe               ║
║  Référence paiement : pi_[stripe_payment_intent_id]         ║
║                                                              ║
╠══════════════════════════════════════════════════════════════╣
║  Conditions :                                                ║
║  - Acompte de 30% à la réservation                          ║
║  - Solde à J-30 avant le départ                             ║
║  - Annulation : voir CGV sur eventy.life/cgv                ║
║  - Médiation : MTV — www.mtv.travel                         ║
║                                                              ║
║  En cas de retard de paiement :                              ║
║  Pénalités = 3× taux d'intérêt légal                        ║
║  Indemnité forfaitaire de recouvrement = 40€                ║
╚══════════════════════════════════════════════════════════════╝
```

---

## Facture prestataire (avoir fournisseur)

La facture reçue du prestataire doit contenir :
- Montant TTC (base de calcul de la marge)
- Référence du voyage Eventy (EV-2026-XXXX)
- Dates de prestation
- Détail des prestations

**Classement** : Par voyage → Par type de prestataire → Chronologique

---

## Numérotation des factures

| Type | Format | Exemple |
|------|--------|---------|
| Facture client | EV-AAAA-XXXX | EV-2026-0001 |
| Avoir client | AV-AAAA-XXXX | AV-2026-0001 |
| Facture proforma | PF-AAAA-XXXX | PF-2026-0001 |

Règles :
- Séquentiel, sans trou
- Remise à 0001 chaque année civile
- Un seul système de numérotation (pas 2 séries)
